<?php
/**
 * Widgets Inline Styles
 *
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly

/**
 * Sliders CSS
 */
function tie_get_inline_sliders_styles( $id = false ){

	$out = '';
	
	switch ( $id ) {
		case 'wide':
			$out = '
				.wide-slider-wrapper .slide {
					height: 400px;
				}

				.wide-slider-wrapper .thumb-overlay {
					padding: 40px;
				}

				.wide-slider-wrapper .thumb-overlay .container {
					position: relative;
					top: 50%;
					-webkit-transform: translateY(-50%);
							-ms-transform: translateY(-50%);
									transform: translateY(-50%);
					z-index: 2;
				}

				.wide-slider-wrapper .thumb-overlay .container:before {
					clear: both;
				}

				.wide-slider-wrapper .thumb-title {
					font-size: 40px;
					color: #ffffff;
					line-height: 1.2;
				}

				.wide-slider-wrapper div.post-rating,
				.wide-slider-wrapper div.digital-rating {
					float: left;
					top: -5px;
					left: 0;
				}

				.wide-slider-wrapper span.tie-media-icon {
					margin: -5px 0 0 0;
				}

				.wide-slider-wrapper span.post-cat-wrap {
					float: none;
					clear: both;
				}

				@media (min-width: 992px) {
					.wide-slider-wrapper .thumb-title {
						display: -webkit-box;
						-webkit-line-clamp: 3;
						-webkit-box-orient: vertical;
						overflow: hidden;
						text-overflow: ellipsis;
						max-height: 4em;
					}
					.full-width .wide-slider-wrapper .slide {
						height: 500px;
					}
					.full-width .wide-slider-wrapper .thumb-title {
						font-size: 50px;
					}
					.full-width .wide-slider-wrapper .post-cat-wrap {
						margin-bottom: 10px;
					}
				}

				@media (max-width: 767px) {
					.wide-slider-wrapper .slide {
						height: 300px;
					}
					.wide-slider-wrapper .thumb-overlay {
						padding: 40px 60px 0;
					}
					.wide-slider-wrapper .thumb-title {
						font-size: 25px;
					}
				}

				@media (max-width: 479px) {
					.wide-slider-wrapper .slide {
						height: 220px;
					}
					.wide-slider-wrapper .thumb-overlay {
						padding: 40px 40px 0;
					}
				}
			';
			break;
		
		case 'centered-title':
			$out = '
				.centered-title-slider .slide .container {
					width: 100%;
				}

				.centered-title-slider .thumb-overlay .container {
					top: 42%;
					text-align: center;
				}

				.centered-title-slider div.thumb-content {
					width: 100%;
					top: 0;
					position: relative;
					padding: 0;
				}

				.centered-title-slider .thumb-title {
					max-width: 450px;
					margin: 0 auto 15px;
				}

				@media (min-width: 992px) {
					.full-width .centered-title-slider .thumb-title {
						max-width: 650px;
					}
				}

				.centered-title-slider .post-cat-wrap {
					margin-bottom: 20px;
					width: 100%;
				}

				@media (max-width: 767px) {
					.centered-title-slider .post-cat-wrap {
						margin-bottom: 20px;
					}
					.centered-title-slider .thumb-meta {
						display: none;
					}
				}
			';
			break;
		
		case 'with-nav':
			$out = '
				.wide-slider-with-navfor-wrapper .thumb-title {
					max-width: 850px;
					display: -webkit-box;
					-webkit-box-orient: vertical;
					overflow: hidden;
					text-overflow: ellipsis;
				}

				@media (min-width: 768px) {
					.wide-slider-with-navfor-wrapper .thumb-title {
						max-height: 2.5em;
						-webkit-line-clamp: 2;
						font-size: 30px;
					}
				}

				@media (min-width: 992px) {
					.full-width .wide-slider-with-navfor-wrapper .thumb-title {
						max-height: 4em;
						-webkit-line-clamp: 3;
						font-size: 40px;
					}
				}

				.wide-slider-nav-wrapper {
					height: 110px;
					overflow: hidden;
					width: 100%;
					position: absolute;
					bottom: 0;
					z-index: 3;
					opacity: 0;
					padding: 0 35px;
					background-color: rgba(0, 0, 0, 0.3);
				}

				@media (max-width: 767px) {
					.wide-slider-nav-wrapper {
						display: none;
					}
				}

				.wide-slider-nav-wrapper .slick-list {
					width: 100%;
				}

				.wide-slider-nav-wrapper .slide {
					cursor: pointer;
					transition: 0.3s;
					height: 110px;
					color: var(--brand-color);
				}

				.wide-slider-nav-wrapper .slick-current {
					box-shadow: inset 0 -5px 0 0;
				}

				.wide-slider-nav-wrapper .slide-overlay {
					padding: 35px 15px 0;
				}

				.wide-slider-nav-wrapper .thumb-meta {
					color: #e6e6e6;
					margin-bottom: 2px;
				}

				.wide-slider-nav-wrapper .thumb-title {
					font-size: 16px;
					color: #ffffff;
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
					word-wrap: normal;
				}

				.wide-slider-nav-wrapper .tie-slider-nav {
					margin: -23px -35px;
					opacity: 1;
				}
			';
			break;
		
		case 'boxed':
			$out = '
				.boxed-slider {
					height: auto;
				}

				.boxed-slider .tie-slick-slider {
					overflow: hidden;
				}

				.boxed-slider .slick-list {
					width: 100%;
					width: calc(100% + 30px);
					margin: 0 -15px;
					overflow: inherit;
				}

				.boxed-slider .slide {
					margin: 0 15px;
					height: 318px;
				}

				.boxed-slider .thumb-overlay {
					padding: 30px;
				}

				.boxed-slider .thumb-title {
					font-size: 20px;
				}

				@media (max-width: 670px) {
					.boxed-slider .thumb-title {
						font-size: 16px;
					}
				}

				.boxed-slider .tie-slick-dots {
					position: relative;
					bottom: -20px;
					height: 0;
					text-align: center;
				}

				.slider-area .boxed-five-slides-slider .slick-dotted,
				.slider-area .boxed-four-taller-slider .slick-dotted,
				.slider-area .boxed-slider-three-slides-wrapper .slick-dotted {
					padding-bottom: 46px;
				}

				.slider-area .boxed-five-slides-slider .tie-slider-nav,
				.slider-area .boxed-four-taller-slider .tie-slider-nav,
				.slider-area .boxed-slider-three-slides-wrapper .tie-slider-nav {
					margin-top: -46px;
				}
			';
			break;


		case 'grid':
			$out = '
				.grid-slider-wrapper .container {
					position: relative;
				}

				.grid-slider-wrapper .slick-list {
					width: 100%;
					margin: 0;
				}

				.grid-slider-wrapper .slide {
					margin: 0;
					height: 500px;
				}

				.grid-slider-wrapper .thumb-overlay,
				.grid-slider-wrapper .thumb-content {
					padding: 20px 20px 15px;
				}

				@media (max-width: 767px) {
					.grid-slider-wrapper .thumb-overlay,
					.grid-slider-wrapper .thumb-content {
						padding: 10px;
					}
				}

				.grid-slider-wrapper .thumb-title {
					font-size: 20px;
				}

				@media (max-width: 991px) {
					.grid-slider-wrapper .thumb-title {
						font-size: 16px;
					}
				}

				@media (max-width: 767px) {
					.grid-slider-wrapper .thumb-title {
						white-space: normal;
						display: block;
						display: -webkit-box;
						-webkit-line-clamp: 2;
						-webkit-box-orient: vertical;
						overflow: hidden;
						text-overflow: ellipsis;
						line-height: 1.4;
						max-height: 2.8em;
					}
				}

				.grid-slider-wrapper .grid-item {
					position: relative;
					overflow: hidden;
					margin-bottom: 4px;
					margin-right: 4px;
					background-repeat: no-repeat;
					background-position: center top;
					background-size: cover;
				}

				.grid-slider-wrapper .grid-item:nth-child(1) {
					float: left;
					width: 50%;
					height: 100%;
				}

				.grid-slider-wrapper .grid-item:nth-child(2), .grid-slider-wrapper .grid-item:nth-child(3) {
					margin-bottom: 4px;
				}

				.grid-slider-wrapper .grid-item:nth-child(n + 2) {
					float: left;
					width: 25%;
					width: calc(25% - 2px);
					height: 50%;
				}

				.has-builder .has-sidebar .grid-slider-wrapper .thumb-desc {
					display: none;
				}

				@media (max-width: 479px) {
					.grid-slider-wrapper .thumb-meta {
						display: none;
					}
				}
			';
			break;


		case 'slider-10-17':
			$out = '
				.grid-3-slides .slide {
					height: 380px;
				}

				@media (max-width: 767px) {
					.grid-3-slides .slide {
						height: 300px;
					}
				}

				@media (min-width: 992px) {
					.full-width .grid-3-slides .slide {
						height: 470px;
					}
				}

				.grid-3-slides .grid-item:nth-child(1) {
					float: left;
					width: 65.7%;
					width: calc(66% - 4px);
					height: calc(100% - 4px);
				}

				.grid-3-slides .grid-item:nth-child(n + 2) {
					width: 34%;
					margin-right: 0;
					height: calc(50% - 4px);
				}

				@media (max-width: 600px) {
					.grid-3-slides .slide {
						display: block;
						height: auto;
					}
					.grid-3-slides .grid-item:nth-child(n) {
						height: 140px;
					}
					.grid-3-slides .grid-item:first-child {
						width: 100%;
						width: 100%;
						height: 200px;
						margin-right: 0;
					}
					.grid-3-slides .grid-item:nth-child(even) {
						width: 49.9%;
						width: calc(50% - 4px);
						margin-right: 4px;
						clear: none;
					}
					.grid-3-slides .grid-item:nth-child(n + 3):nth-child(odd) {
						width: 50%;
						margin-right: 0;
						clear: none;
					}
				}
			';
			break;

		case 'slider-13-14':
			$out = '
				.grid-5-slider .grid-item:nth-child(1) {
					width: 100%;
					width: calc( 100% - 2px);
					height: 50%;
					margin-right: 0;
				}
				
				.grid-5-slider .grid-item:nth-child(2), .grid-5-slider .grid-item:nth-child(3) {
					height: 25%;
					width: 49.9%;
					width: calc(50% - 4px);
				}
				
				.grid-5-slider .grid-item:nth-child(n + 4) {
					height: 25%;
					margin-right: 4px;
					width: calc(50% - 4px);
				}
				
				.grid-5-slider .grid-item:nth-child(n + 3):nth-child(odd) {
					width: 50%;
					width: calc( 50% - 2px);
					margin-right: 0;
				}
				
				.grid-5-slider .slide {
					height: 800px;
				}
				
				@media (max-width: 767px) {
					.grid-5-slider .slide {
						height: 600px;
					}
				}
				
				@media (max-width: 600px) {
					.grid-5-slider .slide {
						height: 500px;
					}
					.grid-5-slider .grid-item:nth-child(1) {
						height: 40%;
					}
					.grid-5-slider .grid-item:nth-child(n + 2) {
						height: 30%;
						height: calc( 30% - 4px);
					}
				}
				
				@media (max-width: 479px) {
					.grid-5-slider .slide {
						height: 470px;
					}
				}
				
				@media (min-width: 992px) {
					.full-width .grid-5-slider .slide {
						height: 470px;
					}
					.full-width .grid-5-slider .grid-item:nth-child(1) {
						width: 50%;
						height: 100%;
						margin-right: 4px;
					}
					.full-width .grid-5-slider .grid-item:nth-child(n + 2) {
						height: calc(50% - 4px);
						width: 24.9%;
						width: calc(25% - 4px);
					}
				}
			';
			break;


		case 1:
			$out .= '
				.fullwidth-slider-wrapper {
					overflow: hidden;
					background: transparent;
				}

				.fullwidth-slider-wrapper .tie-slick-dots {
					position: relative;
					max-width: 850px;
					height: 30px;
					margin: -30px auto 0;
					bottom: 70px;
					padding: 0 60px;
				}

				.has-builder .has-sidebar .fullwidth-slider-wrapper .tie-slick-dots {
					padding: 0 40px;
				}

				.fullwidth-slider-wrapper .thumb-overlay .container {
					max-width: 850px;
					padding: 0;
				}

				.fullwidth-slider-wrapper .post-cat-wrap {
					margin-bottom: 10px;
				}

				.fullwidth-slider-wrapper .thumb-content {
					top: 0;
					position: relative;
					padding: 0;
				}

				@media (min-width: 992px) {
					.full-width .fullwidth-slider-wrapper .tie-slick-dots {
						padding: 0;
					}
					.has-builder .has-sidebar .fullwidth-slider-wrapper .thumb-content {
						top: auto;
						bottom: 20px;
					}
					.has-builder .has-sidebar .fullwidth-slider-wrapper .thumb-title {
						display: -webkit-box;
						-webkit-line-clamp: 2;
						-webkit-box-orient: vertical;
						overflow: hidden;
						text-overflow: ellipsis;
						max-height: 2.5em;
					}
				}

				@media (max-width: 479px) {
					.fullwidth-slider-wrapper .thumb-meta {
						display: none;
					}
				}
			';
			break;


		case 2:
			$out .= '
				.wide-slider-three-slids-wrapper {
					min-height: 390px;
				}
				
				.wide-slider-three-slids-wrapper .slide {
					height: 390px;
				}
				
				.wide-slider-three-slids-wrapper .thumb-overlay {
					padding: 20px;
				}
				
				.wide-slider-three-slids-wrapper .thumb-overlay .container {
					padding: 0;
				}
				
				.wide-slider-three-slids-wrapper .thumb-content {
					padding: 20px;
				}
				
				.wide-slider-three-slids-wrapper .thumb-title {
					font-size: 24px;
				}
				
				@media (max-width: 1199px) {
					.wide-slider-three-slids-wrapper {
						min-height: 330px;
					}
					.wide-slider-three-slids-wrapper .slide {
						height: 330px;
					}
				}
				
				@media (max-width: 767px) {
					.wide-slider-three-slids-wrapper {
						min-height: 280px;
					}
					.wide-slider-three-slids-wrapper .slide {
						height: 280px;
					}
					.wide-slider-three-slids-wrapper .thumb-title {
						font-size: 20px;
					}
				}
				
				@media (max-width: 479px) {
					.wide-slider-three-slids-wrapper {
						min-height: 220px;
					}
					.wide-slider-three-slids-wrapper .slide {
						height: 220px;
					}
				}
			';
			break;


			

		case 3:
			$out .= '
				.wide-next-prev-slider-wrapper .slider-main-container {
					max-width: 1200px;
					padding: 0 15px;
				}

				.wide-next-prev-slider-wrapper .slick-list {
					width: 100%;
					padding: 0 !important;
					overflow: inherit;
				}

				.wide-next-prev-slider-wrapper .tie-slider-nav {
					width: 90%;
					left: 5%;
					opacity: 1;
				}

				.wide-next-prev-slider-wrapper .tie-slider-nav span {
					background: transparent !important;
					color: #ffffff;
					font-size: 80px;
				}

				.wide-next-prev-slider-wrapper .tie-slider-nav li:hover span {
					color: var(--brand-color);
				}

				@media (max-width: 767px) {
					.wide-next-prev-slider-wrapper .tie-slider-nav {
						left: 1%;
						width: 98%;
					}
					.wide-next-prev-slider-wrapper .tie-slider-nav span {
						font-size: 50px;
					}
				}
			';
			break;


		case 5:
			$out .= '
				.boxed-slider-three-slides-wrapper {
					min-height: 318px;
				}

				.boxed-slider-three-slides-wrapper .thumb-overlay,
				.boxed-slider-three-slides-wrapper .thumb-content {
					padding: 20px;
				}

				@media (max-width: 1024px) {
					.boxed-slider-three-slides-wrapper {
						min-height: 280px;
					}
					.boxed-slider-three-slides-wrapper .slide {
						height: 280px;
					}
				}

				@media (max-width: 767px) {
					.boxed-slider-three-slides-wrapper {
						min-height: 220px;
					}
					.boxed-slider-three-slides-wrapper .slide {
						height: 220px;
					}
				}
			';
			break;


		case 6:
			$out .= '
				.boxed-five-slides-slider {
					min-height: 155px;
				}

				.boxed-five-slides-slider .slide {
					height: 155px;
				}

				@media (max-width: 550px) {
					.boxed-five-slides-slider .slide {
						height: 180px;
					}
				}

				.boxed-five-slides-slider .thumb-overlay,
				.boxed-five-slides-slider div.thumb-content {
					padding: 10px;
				}

				.boxed-five-slides-slider .thumb-meta {
					margin-bottom: 0;
				}

				.boxed-five-slides-slider .thumb-title {
					margin-bottom: 0;
					font-size: 14px;
					pointer-events: none;
				}

				.boxed-five-slides-slider span.tie-media-icon {
					width: 30px;
					height: 30px;
					margin: 0;
				}

				.boxed-five-slides-slider .tie-media-icon:before, .boxed-five-slides-slider .tie-media-icon:after {
					width: 30px;
					height: 30px;
				}

				.boxed-five-slides-slider .tie-media-icon:before {
					line-height: 26px;
					font-size: 12px;
				}
			';
			break;


		case 7:
			$out .= '
				.boxed-four-taller-slider {
					margin-bottom: 10px;
					min-height: 440px;
				}

				.boxed-four-taller-slider .slick-list {
					width: calc(100% + 1px);
					margin: 0 -2px;
				}

				.boxed-four-taller-slider .slide {
					margin: 0 2px;
					height: 440px;
				}

				.boxed-four-taller-slider .thumb-overlay,
				.boxed-four-taller-slider .thumb-content {
					padding: 20px;
				}

				@media (max-width: 1024px) {
					.boxed-four-taller-slider {
						min-height: 220px;
					}
					.boxed-four-taller-slider .slide {
						height: 220px;
					}
					.boxed-four-taller-slider .thumb-title {
						display: -webkit-box;
						-webkit-line-clamp: 3;
						-webkit-box-orient: vertical;
						overflow: hidden;
						text-overflow: ellipsis;
						line-height: 1.4;
						max-height: 4.2em;
					}
				}

				@media (max-width: 900px) {
					.boxed-four-taller-slider {
						min-height: 180px;
					}
					.boxed-four-taller-slider .slide {
						height: 180px;
					}
				}
			';
			break;



		case 8:
			$out .= '
				.boxed-slider-wrapper {
					height: auto;
				}

				.boxed-slider-wrapper .slick-list {
					margin: 0;
					width: 100%;
					overflow: hidden;
				}

				.boxed-slider-wrapper .slide {
					margin: 0;
					height: 380px;
				}

				.boxed-slider-wrapper .tie-slick-dots {
					position: absolute;
					bottom: 30px;
					right: 30px;
					width: calc(100% - 60px);
					height: 6px;
					text-align: right;
				}

				.boxed-slider-wrapper .tie-slick-dots li {
					vertical-align: top;
				}

				.boxed-slider-wrapper .thumb-title {
					font-size: 38px;
				}

				@media (min-width: 992px) {
					.full-width .boxed-slider-wrapper .slide {
						height: 480px;
					}
					.boxed-slider-wrapper .thumb-content {
						max-width: 80%;
					}
				}

				@media (max-width: 991px) {
					.boxed-slider-wrapper .thumb-desc {
						display: none;
					}
				}

				@media (max-width: 767px) {
					.boxed-slider-wrapper .slide {
						height: 300px;
					}
					.boxed-slider-wrapper .thumb-overlay,
					.boxed-slider-wrapper .thumb-content {
						padding: 20px;
					}
					.boxed-slider-wrapper .thumb-title {
						font-size: 25px;
					}
				}

				@media (max-width: 670px) {
					.boxed-slider-wrapper .slide {
						height: 250px;
					}
				}

				@media (max-width: 479px) {
					.boxed-slider-wrapper .slide {
						height: 200px;
					}
					.boxed-slider-wrapper .thumb-title {
						font-size: 20px;
					}
				}

				.boxed-slider-wrapper .tie-slick-slider:hover .thumb-overlay:after {
					opacity: 0.9;
				}
			';
			break;



		case 9:
			$out .= '
				.grid-2-big .slide {
					height: 360px;
				}

				@media (min-width: 992px) {
					.full-width .grid-2-big .slide {
						height: 400px;
					}
				}

				@media (min-width: 768px) {
					.grid-2-big .thumb-title {
						font-size: 30px;
					}
				}

				@media (max-width: 767px) {
					.grid-2-big .slide {
						height: 200px;
					}
				}

				.grid-2-big .grid-item {
					float: left;
					width: 49.5%;
					width: calc(50% - 4px);
					height: 100%;
				}

				.grid-2-big .grid-item:nth-child(2) {
					width: calc(50% - 4px);
					height: 100%;
					margin-right: 0;
				}

				.has-builder .has-sidebar .grid-2-big .thumb-desc {
					display: block;
				}

				@media (max-width: 479px) {
					.grid-2-big .slide {
						height: auto;
					}
					.grid-2-big .grid-item:nth-child(n) {
						width: 100%;
						width: calc(100% - 4px);
						margin-right: 0;
						height: 180px;
					}
				}
			';
			break;



		case 11:
			$out .= '
				.grid-4-slides .slide {
					height: auto;
				}

				.grid-4-slides .grid-item:nth-child(n) {
					width: 49.9%;
					width: calc(50% - 4px);
					height: 180px;
				}

				@media (min-width: 992px) {
					.full-width .grid-4-slides .grid-item:nth-child(n) {
						height: 250px;
					}
				}

				@media (max-width: 767px) {
					.grid-4-slides .grid-item:nth-child(n) {
						height: 150px;
					}
				}

				.grid-4-slides .grid-item:nth-child(2), .grid-4-slides .grid-item:nth-child(4) {
					width: 50%;
					margin-right: 0;
				}

				.grid-4-slides .grid-item:nth-child(odd):last-child {
					margin-right: 0;
					margin-left: 0;
					width: 100%;
				}
			';
			break;

			

		case 12:
			$out .= '
				.grid-5-in-rows .slide {
					height: auto;
				}
				
				.grid-5-in-rows .grid-item:nth-child(n) {
					height: 180px;
				}
				
				@media (min-width: 992px) {
					.full-width .grid-5-in-rows .grid-item:nth-child(n) {
						height: 250px;
					}
				}
				
				@media (max-width: 767px) {
					.grid-5-in-rows .grid-item:nth-child(n) {
						height: 150px;
					}
				}
				
				.grid-5-in-rows .grid-item:nth-child(1), .grid-5-in-rows .grid-item:nth-child(2) {
					width: 49.9%;
					width: calc(50% - 2px);
				}
				
				.grid-5-in-rows .grid-item:nth-child(2) {
					margin-right: 0;
				}
				
				.grid-5-in-rows .grid-item:nth-child(3) {
					clear: left;
				}
				
				.grid-5-in-rows .grid-item:nth-child(3), .grid-5-in-rows .grid-item:nth-child(4) {
					width: 33.2%;
					width: calc(33.3334% - 4px);
				}
				
				.grid-5-in-rows .grid-item:nth-child(5) {
					width: calc(33.337% - 2px);
					margin-right: 0;
				}
				
				@media (max-width: 991px) {
					.grid-5-in-rows .grid-item:nth-child(5) {
						width: 33.334%;
					}
				}
			';
			break;

		case 13:
			$out .= '
				.grid-5-big-centerd .slide {
					display: -webkit-flex;
					display: -ms-flexbox;
					display: flex;
					-webkit-flex-flow: row wrap;
							-ms-flex-flow: row wrap;
									flex-flow: row wrap;
				}

				.grid-5-big-centerd .tie-slider-nav + .slide {
					display: -webkit-flex !important;
					display: -ms-flexbox !important;
					display: flex !important;
				}

				.grid-5-big-centerd .grid-item:nth-child(n + 2) {
					height: 49.9%;
					height: calc(50% - 4px);
				}

				.grid-5-big-centerd .grid-item:nth-child(1) {
					-webkit-order: 3;
							-ms-flex-order: 3;
									order: 3;
				}

				.grid-5-big-centerd .grid-item:nth-child(2) {
					-webkit-order: 1;
							-ms-flex-order: 1;
									order: 1;
				}

				.grid-5-big-centerd .grid-item:nth-child(3) {
					-webkit-order: 2;
							-ms-flex-order: 2;
									order: 2;
				}

				.grid-5-big-centerd .grid-item:nth-child(4) {
					-webkit-order: 4;
							-ms-flex-order: 4;
									order: 4;
				}

				.grid-5-big-centerd .grid-item:nth-child(5) {
					-webkit-order: 5;
							-ms-flex-order: 5;
									order: 5;
				}

				.grid-5-big-centerd .grid-item:nth-child(n + 4) {
					width: 25%;
					margin-right: 0;
				}

				@media (min-width: 992px) {
					.full-width .grid-5-big-centerd .slide {
						-webkit-flex-flow: column wrap;
								-ms-flex-flow: column wrap;
										flex-flow: column wrap;
						-webkit-align-content: flex-start;
								-ms-flex-line-pack: start;
										align-content: flex-start;
						box-orient: vertical;
						box-direction: normal;
					}
				}
			';
			break;

		case 14:
			$out .= '
				@media (min-width: 992px) {
					.full-width .grid-5-first-big .grid-item:nth-child(n + 2) {
						height: calc(50% - 2px);
					}
				}
			';
			break;


		case 15:
			$out .= '
				.grid-6-slides {
					min-height: 180px;
				}
				
				@media (max-width: 991px) {
					.grid-6-slides {
						min-height: 100px;
					}
				}
				
				.grid-6-slides .slide {
					height: auto;
				}
				
				.grid-6-slides .grid-item {
					float: left;
				}
				
				.grid-6-slides .grid-item:nth-child(n) {
					height: 180px;
					width: 33.1%;
					width: calc(33.1% - 3px);
				}
				
				@media (min-width: 992px) {
					.full-width .grid-6-slides .grid-item:nth-child(n) {
						height: 225px;
					}
				}
				
				@media (max-width: 767px) {
					.grid-6-slides .grid-item:nth-child(n) {
						height: 145px;
					}
				}
				
				.grid-6-slides .grid-item:nth-child(4) {
					clear: left;
				}
				
				.grid-6-slides .grid-item:nth-child(3), .grid-6-slides .grid-item:nth-child(6) {
					width: calc(33.337% - 2.5px);
					margin-right: 0;
				}
				
				@media (max-width: 991px) {
					.grid-6-slides .grid-item:nth-child(3), .grid-6-slides .grid-item:nth-child(6) {
						width: 33.32%;
					}
				}
				
				@media (max-width: 600px) {
					.grid-6-slides .slide {
						display: -webkit-flex;
						display: -ms-flexbox;
						display: flex;
						-webkit-flex-flow: row wrap;
								-ms-flex-flow: row wrap;
										flex-flow: row wrap;
					}
					.grid-6-slides .tie-slider-nav + .slide {
						display: -webkit-flex !important;
						display: -ms-flexbox !important;
						display: flex !important;
					}
					.grid-6-slides .grid-item:nth-child(odd) {
						width: calc(50% - 4px);
						margin-right: 4px;
						-webkit-flex-grow: 1;
								-ms-flex-positive: 1;
										flex-grow: 1;
					}
					.grid-6-slides .grid-item:nth-child(odd):last-child {
						margin-right: 0;
						margin-left: 0;
					}
					.grid-6-slides .grid-item:nth-child(even) {
						width: 50%;
						-webkit-flex-grow: 0;
								-ms-flex-positive: 0;
										flex-grow: 0;
						margin-right: 0;
						clear: none;
					}
				}
			';
			break;


		case 16:
			$out .= '
				.grid-4-big-first-half-second .slide {
					height: 700px;
					display: block;
				}
				
				@media (max-width: 767px) {
					.grid-4-big-first-half-second .slide {
						height: 480px;
					}
				}
				
				.grid-4-big-first-half-second .grid-item:nth-child(1) {
					height: 40%;
					width: 100%;
				}
				
				.grid-4-big-first-half-second .grid-item:nth-child(2) {
					height: calc(30% - 4px);
					width: 100%;
				}
				
				.grid-4-big-first-half-second .grid-item:nth-child(3) {
					height: calc(30% - 4px);
					margin-right: 4px;
					width: calc(50% - 4px);
				}
				
				.grid-4-big-first-half-second .grid-item:nth-child(4) {
					width: 50%;
					height: calc(30% - 4px);
					margin-right: 0;
				}
				
				.grid-4-big-first-half-second .grid-item:nth-child(odd):last-child {
					margin-right: 0;
					margin-left: 0;
					width: 100%;
				}
				
				@media (min-width: 992px) {
					.full-width .grid-4-big-first-half-second .slide {
						height: 450px;
					}
					.full-width .grid-4-big-first-half-second .grid-item {
						float: left;
						height: calc(50% - 2px);
					}
					.full-width .grid-4-big-first-half-second .grid-item:nth-child(1) {
						height: 100%;
						width: calc(50% - 4px);
					}
					.full-width .grid-4-big-first-half-second .grid-item:nth-child(2) {
						width: 50%;
						margin-right: 0;
					}
					.full-width .grid-4-big-first-half-second .grid-item:nth-child(3) {
						width: 24.9%;
						width: calc(25% - 4px);
					}
					.full-width .grid-4-big-first-half-second .grid-item:nth-child(4) {
						width: 25%;
						margin-right: 0;
					}
				}
			';
			break;

		case 17:
			$out .= '
				@media (min-width: 992px) {
					.full-width .grid-3-slides-half-first .grid-item:nth-child(1) {
						width: calc(50% - 4px);
						height: 100%;
					}
					.full-width .grid-3-slides-half-first .grid-item:nth-child(2) {
						width: calc(25% - 4px);
						margin-right: 4px;
						height: 100%;
					}
					.full-width .grid-3-slides-half-first .grid-item:nth-child(3) {
						width: 25%;
						margin-right: 0;
						height: 100%;
					}
				}
			';
			break;



		case 50:
			$out .= '
				.slider-vertical-navigation {
					position: relative;
					z-index: 1;
				}

				.slider-vertical-navigation .post-cat-wrap {
					margin-bottom: 10px;
				}

				.slider-vertical-navigation .thumb-meta {
					display: -webkit-flex;
					display: -ms-flexbox;
					display: flex;
				}

				.slider-vertical-navigation span.icon {
					float: left;
					margin-right: 10px;
				}

				.slider-vertical-navigation div.post-rating {
					top: 5px;
				}

				@media (min-width: 768px) {
					.slider-vertical-navigation .slider-main-container .thumb-overlay {
						padding-top: 90px;
					}
					.slider-vertical-navigation .slider-main-container .thumb-overlay .container {
						top: 20px;
						-webkit-transform: none;
								-ms-transform: none;
										transform: none;
						width: 60%;
						margin-left: 0;
						padding: 0;
					}
				}

				.slider-vertical-navigation .thumb-meta > span {
					display: inline-block;
				}

				.slider-vertical-navigation .slick-initialized .post-cat-wrap,
				.slider-vertical-navigation .slick-initialized .thumb-meta,
				.slider-vertical-navigation .slick-initialized .thumb-title {
					overflow: hidden;
				}

				.slider-vertical-navigation .slick-initialized .post-cat-wrap a,
				.slider-vertical-navigation .slick-initialized .thumb-meta > span,
				.slider-vertical-navigation .slick-initialized .thumb-title a,
				.slider-vertical-navigation .slick-initialized .read-next-button {
					opacity: 0;
					-webkit-transform: translateY(40px);
							-ms-transform: translateY(40px);
									transform: translateY(40px);
					transition: 1s;
				}

				.slider-vertical-navigation .slick-initialized .thumb-title a {
					display: block;
					-webkit-transform: translateY(140px);
							-ms-transform: translateY(140px);
									transform: translateY(140px);
				}

				.slider-vertical-navigation .slick-current .post-cat-wrap a,
				.slider-vertical-navigation .slick-current .thumb-meta > span,
				.slider-vertical-navigation .slick-current .thumb-title a,
				.slider-vertical-navigation .slick-current .read-next-button {
					opacity: 1;
					-webkit-transform: translateY(0);
							-ms-transform: translateY(0);
									transform: translateY(0);
				}

				.slider-vertical-navigation .thumb-content {
					padding: 0;
					position: relative;
				}

				.has-sidebar .slider-vertical-navigation .wide-slider-nav-wrapper {
					padding: 0 15px 0 0;
				}

				.vertical-slider-nav {
					top: 0;
					right: 0;
					left: auto;
					width: 30%;
					height: 100%;
					padding: 0 15px;
					background: transparent;
				}

				.vertical-slider-nav .slick-list {
					max-height: 500px;
				}

				.vertical-slider-nav .slide {
					height: auto;
					margin-bottom: 20px;
					box-shadow: inset 0 0 0 0 #fff;
					transition: 0.5s 0.3s;
					opacity: 0.5;
					transition: opacity 0.3s;
				}

				.vertical-slider-nav .slide-overlay {
					padding: 20px 0;
				}

				.vertical-slider-nav .container {
					position: relative;
					top: 50%;
					-webkit-transform: translateY(-50%);
							-ms-transform: translateY(-50%);
									transform: translateY(-50%);
				}

				.vertical-slider-nav .thumb-title {
					font-size: 19px;
					line-height: 1.4em;
					max-height: 2.8em;
					font-weight: 300;
					white-space: inherit;
				}

				.vertical-slider-nav .thumb-meta {
					display: none;
				}

				.vertical-slider-nav .slick-current {
					opacity: 1;
				}

				.section-item.has-sidebar .vertical-slider-nav,
				.single-post.has-sidebar .vertical-slider-nav {
					width: 40%;
				}

				.section-item.has-sidebar .vertical-slider-nav .slide-overlay,
				.single-post.has-sidebar .vertical-slider-nav .slide-overlay {
					padding: 15px 0;
				}

				.section-item.has-sidebar .vertical-slider-nav .thumb-title,
				.single-post.has-sidebar .vertical-slider-nav .thumb-title {
					font-size: 14px;
				}

				.vertical-slider-nav:before, .vertical-slider-nav:after {
					content: "";
					position: absolute;
					top: -25px;
					left: 0;
					width: 100%;
					height: 40px;
					z-index: 1;
					background: radial-gradient(ellipse at center, rgba(0, 0, 0, 0.8) 0%, rgba(204, 204, 204, 0) 65%, rgba(229, 229, 229, 0) 100%);
				}

				.vertical-slider-nav:after {
					bottom: -25px;
					top: auto;
				}

				.vertical-slider-nav .tie-slider-nav {
					width: auto;
					height: 100%;
					top: 0;
					margin: 0;
					left: calc(50% - 23px);
					z-index: 2;
				}

				.vertical-slider-nav .tie-slider-nav li {
					position: absolute;
					width: 46px;
					height: 25px;
					transition: opacity 0.4s, -webkit-transform 0.3s;
					transition: transform 0.3s, opacity 0.4s;
					transition: transform 0.3s, opacity 0.4s, -webkit-transform 0.3s;
					opacity: 0;
					-webkit-transform: translateY(-100%);
							-ms-transform: translateY(-100%);
									transform: translateY(-100%);
				}

				.vertical-slider-nav .tie-slider-nav li span {
					width: 46px;
					height: 25px;
					line-height: 25px;
					border-radius: 0 0 2px 2px;
					-webkit-transform: none !important;
							-ms-transform: none !important;
									transform: none !important;
				}

				.vertical-slider-nav .tie-slider-nav li span:before {
					-webkit-transform: rotate(-90deg);
							-ms-transform: rotate(-90deg);
									transform: rotate(-90deg);
					display: inline-block;
				}

				.vertical-slider-nav .tie-slider-nav li:first-child {
					bottom: 0;
					-webkit-transform: translateY(100%);
							-ms-transform: translateY(100%);
									transform: translateY(100%);
				}

				.vertical-slider-nav .tie-slider-nav li:first-child span {
					border-radius: 2px 2px 0 0;
				}

				.vertical-slider-nav:hover .tie-slider-nav li {
					opacity: 1;
					-webkit-transform: translateY(0);
							-ms-transform: translateY(0);
									transform: translateY(0);
				}
			';
			break;
	}

	return apply_filters( 'TieLabs/inline_styles/sliders', $out, $id );
}