<?php
/**
 * Widgets Inline Styles
 *
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly



/**
 * Blocks CSS
 */
function tie_get_inline_blocks_styles( $id = false ){

	$out = '';
	
	switch ( $id ) {

		case 'default':
			$out = '
				.wide-post-box .posts-items {
					margin: 0;
				}
				
				.wide-post-box .posts-items li {
					width: 100%;
					padding: 0;
					display: -webkit-flex !important;
					display: -ms-flexbox !important;
					display: flex !important;
				}
				
				.wide-post-box .posts-items li .post-title {
					font-size: 20px;
				}
				
				.wide-post-box .posts-items li .post-thumb {
					margin-right: 25px;
					float: none;
					-webkit-flex: 0 0 50%;
							-ms-flex: 0 0 50%;
									flex: 0 0 50%;
					width: 50%;
					max-width: 420px;
				}
				
				@media (max-width: 767px) {
					.wide-post-box .posts-items li .post-thumb {
						-webkit-flex: 1 0 40%;
								-ms-flex: 1 0 40%;
										flex: 1 0 40%;
						width: 40%;
						max-width: 40%;
						margin-right: 3.55%;
					}
				}
				
				.wide-post-box .posts-items li .post-details {
					-webkit-flex: 1 1 auto;
							-ms-flex: 1 1 auto;
									flex: 1 1 auto;
					padding: 0 !important;
				}
				
				@media (max-width: 580px) {
					.wide-post-box .posts-items li {
						-webkit-flex-direction: column;
								-ms-flex-direction: column;
										flex-direction: column;
					}
					.wide-post-box .posts-items li .post-thumb {
						width: 100%;
						-webkit-flex: 1 0 100%;
								-ms-flex: 1 0 100%;
										flex: 1 0 100%;
						max-width: 100%;
						margin: 0 0 10px 0;
					}
					.wide-post-box .posts-items li .post-meta {
						width: 100%;
					}
				}
			';
			break;

		case 'classic-small':
			$out = '
				.small-wide-post-box .posts-items li .post-thumb{
					flex: 0 0 30%;
				}
			';
			break;

		case 'full_thumb':
			$out = '
				.full-width-img-news-box .posts-items li {
					width: 100%;
					float: none;
				}
				
				@media (min-width: 992px) {
					.full-width-img-news-box .posts-items li:not(:first-child) {
						margin-top: 40px;
					}
				}
				
				.full-width-img-news-box .posts-items li .post-title {
					font-size: 30px;
					line-height: 1.2;
				}
				
				@media (max-width: 767px) {
					.full-width-img-news-box .posts-items li .post-title {
						font-size: 25px;
					}
				}
				
				@media (max-width: 670px) {
					.full-width-img-news-box .posts-items li .post-title {
						font-size: 20px;
					}
				}
				
				.full-width-img-news-box .posts-items li .post-thumb {
					width: 100%;
					margin-bottom: 10px;
					float: none !important;
				}
				
				.full-width-img-news-box .posts-items .post-meta {
					clear: both;
				}
				
				.full-width-img-news-box .posts-items .post-excerpt,
				.full-width-img-news-box .posts-items .entry {
					margin-top: 10px;
				}
			';
			break;

		case 'overlay-title':
			$out = '
				@media (min-width: 768px) {
					.full-overlay-title li:not(.no-post-thumb) .block-post-overlay {
						position: relative;
						margin-bottom: 20px;
					}
					.full-overlay-title li:not(.no-post-thumb) .block-title-overlay {
						position: absolute;
						bottom: -1px;
						padding: 25px 25px 0 0;
						background: #ffffff;
						z-index: 4;
						width: 70%;
					}
					.full-overlay-title li:not(.no-post-thumb) img {
						min-height: 250px;
						background-color: #f6f7f8;
					}
					.full-overlay-title.dark-skin li:not(.no-post-thumb) img,
					.dark-skin .full-overlay-title li:not(.no-post-thumb) img {
						background-color: #161619;
					}
					.full-overlay-title.media-overlay .tie-media-icon {
						left: 15px;
						top: 15px;
						-webkit-transform: none;
								-ms-transform: none;
										transform: none;
					}
					.full-overlay-title.media-overlay .is-trending .trending-post {
						top: 16px;
						left: 15px;
						width: 38px;
						height: 38px;
						line-height: 38px;
					}
					.full-overlay-title.media-overlay .is-trending .tie-media-icon {
						left: 63px;
					}
					.full-overlay-title .digital-rating {
						top: 15px;
						right: 15px;
					}
				}
			';
			break;

		case 'overlay-title-center':
			$out = '
				@media (min-width: 768px) {
				.center-overlay-title li:not(.no-post-thumb) .block-title-overlay {
					padding: 25px 25px 15px 25px !important;
					width: 86%;
					left: 7%;
					text-align: center;
				}
				.center-overlay-title li:not(.no-post-thumb) .tie-alignright {
					float: none;
					display: inline-block;
				}
			';
			break;

		case 'first-post-gradient':
			$out = '
				.first-post-gradient li:first-child .post-title {
					font-size: 25px;
					line-height: 1.2;
					margin: 5px 0;
				}
				
				.first-post-gradient li:first-child .post-overlay {
					pointer-events: none;
					position: absolute;
					top: 0;
					height: 100%;
					width: 100%;
					border-radius: 2px;
					z-index: 2;
				}
				
				.first-post-gradient li:first-child .post-content {
					width: 100%;
					padding: 22px 30px;
					position: absolute;
					bottom: 0;
					left: 0;
				}
				
				.first-post-gradient li:first-child .post-cat-wrap {
					pointer-events: none;
				}
				
				.first-post-gradient li:first-child .post-cat-wrap a,
				.first-post-gradient li:first-child .meta-author a {
					pointer-events: auto;
				}
				
				.first-post-gradient .posts-items li:first-child a:not(:hover),
				.first-post-gradient li:first-child .post-meta {
					color: #ffffff;
				}
			';
			break;

		case 'big_thumb':
			$out = '
				.big-thumb-left-box-inner {
					height: 470px;
					position: relative;
					background-repeat: no-repeat;
					background-position: center top;
					background-size: cover;
					background-color: rgba(0, 0, 0, 0.2);
				}
				
				@media (max-width: 670px) {
					.big-thumb-left-box-inner {
						height: 325px;
					}
				}
				
				.big-thumb-left-box li:first-child .post-content {
					padding: 12px 20px;
				}
				
				.big-thumb-left-box li:first-child .post-thumb {
					margin-bottom: 0;
				}
			';
			break;

		case 'li':
			$out = '
				.big-post-left-box .posts-items {
					font-size: 0;
				}
				
				.big-post-left-box .posts-items .post-excerpt {
					font-size: 13px;
				}
				
				.big-post-left-box .posts-items li:nth-child(n + 2) {
					float: none;
					display: inline-block;
					vertical-align: top;
				}
				
				.big-post-left-box .posts-items li:nth-child(n + 2) .post-thumb img {
					max-width: 110px;
				}
				
				.big-post-left-box li:first-child .post-thumb {
					margin-bottom: 10px;
				}
				
				@media (min-width: 992px) {
					.full-width .big-post-left-box .posts-items li {
						width: calc(100% / 3);
					}
					.full-width .big-post-left-box .posts-items li:nth-child(3) {
						margin-top: 0;
					}
				}
			';
			break;

		case '1c':
			$out = '
				.big-post-top-box .posts-items li:first-child {
					width: 96%;
					padding-left: 0;
					padding-right: 0;
					margin-left: 2%;
					margin-bottom: 24px;
				}

				.big-post-top-box .posts-items li:first-child .post-thumb {
					float: left;
					width: 48%;
					margin-right: 4%;
					margin-bottom: 0;
				}

				.big-post-top-box .posts-items li:first-child .post-details {
					padding-left: 52%;
				}

				.big-post-top-box .posts-items li:nth-child(2n) {
					clear: left;
				}

				.big-post-top-box .posts-items li:nth-child(-n + 3) {
					margin-top: 0;
				}

				.big-post-top-box .posts-items li:nth-child(n + 2) .post-thumb img {
					max-width: 110px;
				}

				@media (max-width: 670px) {
					.big-post-top-box .posts-items li:first-child {
						margin-bottom: 14px;
					}
					.big-post-top-box .posts-items li:first-child .post-thumb {
						width: 100%;
						margin: 0 0 10px;
					}
					.big-post-top-box .posts-items li:first-child .post-meta {
						width: 100%;
					}
					.big-post-top-box .posts-items li:first-child .post-details {
						padding: 0;
					}
					.big-post-top-box .posts-items li:nth-child(3),
					.big-post-top-box .posts-items li:nth-child(4) {
						margin-top: 14px;
					}
				}

				@media (min-width: 992px) {
					.full-width .big-post-top-box .posts-items li {
						width: calc(100% / 3);
					}
					.full-width .big-post-top-box .posts-items li:nth-child(-n + 4) {
						margin-top: 0;
					}
					.full-width .big-post-top-box .posts-items li:first-child {
						width: 96%;
					}
					.full-width .big-post-top-box .posts-items li:first-child .post-thumb {
						width: 30.6%;
					}
					.full-width .big-post-top-box .posts-items li:first-child .post-details {
						padding-left: 34.767%;
					}
					.full-width .big-post-top-box .posts-items li:nth-child(2n) {
						clear: none;
					}
					.full-width .big-post-top-box .posts-items li:nth-child(3n + 2) {
						clear: left;
					}
				}
			';
			break;

		case 'grid':
			$out = '
				.news-gallery .mag-box-container {
					overflow: hidden;
					margin-bottom: -10px;
				}

				.news-gallery-items {
					width: calc(100% + 10px);
					margin: 0 -5px;
				}

				.news-gallery-items li {
					float: left;
					height: 75px;
					width: 16.66667%;
					padding: 0 5px 10px;
				}

				.news-gallery-items li .post-thumb {
					background-color: rgba(0, 0, 0, 0.2);
					background-size: cover;
					background-position: center top;
					background-repeat: no-repeat;
					float: none !important;
					margin: 0 !important;
				}

				.media-overlay .news-gallery-items .post-thumb-overlay {
					transition: 0.3s;
				}

				.media-overlay .news-gallery-items li:hover .post-thumb-overlay {
					background: rgba(255, 255, 255, 0.2);
				}

				.big-first-gallery .news-gallery-items {
					height: 280px;
				}

				.big-first-gallery .news-gallery-items li {
					height: 25%;
				}

				.big-first-gallery .news-gallery-items li:first-child {
					width: 50%;
					height: 100%;
				}

				@media (min-width: 992px) {
					.full-width .big-first-gallery .news-gallery-items {
						height: 400px;
					}
					.full-width .news-grid .news-gallery-items li {
						height: 100px;
					}
				}

				@media (max-width: 767px) {
					.news-gallery-items li,
					.big-first-gallery .news-gallery-items li {
						width: 33.3334%;
						height: 95px;
					}
					.big-first-gallery .news-gallery-items {
						height: 620px;
					}
					.big-first-gallery .news-gallery-items li:first-child {
						width: 100%;
						height: 250px;
					}
				}
			';
			break;
			
		case 'scroll':
			$out = '
				.scrolling-box .mag-box-container {
					min-height: 150px;
				}

				.scrolling-slider {
					overflow: hidden;
					display: none;
				}

				.scrolling-slider.slick-dotted {
					padding-bottom: 40px;
				}

				.scrolling-slider .slick-list {
					width: 100%;
					width: calc(100% + 24px);
					margin-right: calc(-12px);
					margin-left: calc(-12px);
					overflow: inherit;
					transition: height 0.3s;
				}

				.scrolling-slider .tie-slick-dots {
					bottom: 0;
					text-align: center;
				}

				.scrolling-slider .slide {
					margin: 0 12px;
					position: relative;
				}

				.scrolling-slider .post-title {
					font-size: 16px;
					margin-top: 8px;
				}

				.scrolling-slider .post-meta {
					margin: 8px 0 0;
				}
			';
			break;

		case 'scroll_2':
			$out = '
				.scroll-2-box .slick-track {
					display: -webkit-flex;
					display: -ms-flexbox;
					display: flex;
				}
				
				.scroll-2-box .slide {
					display: -webkit-flex;
					display: -ms-flexbox;
					display: flex;
					-webkit-align-items: center;
							-ms-flex-align: center;
									align-items: center;
					height: auto;
					background-color: rgba(0, 0, 0, 0.2);
				}

				.scroll-2-box .post-overlay {
					pointer-events: none;
					position: absolute;
					top: 0;
					left: 0;
					z-index: 1;
					height: 100%;
					width: 100%;
					padding: 10px;
				}

				.scroll-2-box .post-content {
					position: absolute;
					bottom: 0;
					left: 0;
					padding: 10px;
					width: 100%;
				}

				.scroll-2-box .post-title a {
					color: #ffffff;
					white-space: normal;
					display: block;
					display: -webkit-box;
					-webkit-line-clamp: 3;
					-webkit-box-orient: vertical;
					overflow: hidden;
					text-overflow: ellipsis;
					max-height: 4.2em;
				}

				@media only screen and (min-width: 400px) and (max-width: 570px) {
					.scroll-2-box .post-title a {
						-webkit-line-clamp: 2;
						max-height: 2.8em;
					}
				}

				.scroll-2-box .post-thumb:after {
					opacity: 0.5;
				}

				.scroll-2-box .slide:hover .post-thumb:after {
					opacity: 0.9;
				}
			';
			break;

		case 'half_box':
			$out = '
				.half-box.mag-box {
					padding-left: 0;
					clear: right;
				}

				.half-box.second-half-box {
					padding-left: 15px;
					padding-right: 0;
				}

				@media (max-width: 767px) {
					.half-box {
						padding: 0 !important;
					}
				}

				@media (min-width: 768px) {
					.content-only.first-half-box {
						padding-right: 15px;
					}
				}
			';
			break;
			
		case '2c':
			$out = '
				.half-box .posts-items {
					margin: 0;
				}

				.half-box .posts-items li {
					width: 100%;
					padding: 0;
				}

				.half-box .posts-items li:first-child {
					margin-bottom: 24px;
				}

				@media (max-width: 670px) {
					.half-box .posts-items li:first-child {
						margin-bottom: 14px;
					}
				}

				.half-box .posts-items li:first-child .post-thumb {
					margin-bottom: 10px;
				}

				.half-box .posts-items li:nth-child(2) {
					margin-top: 0;
				}

				.half-box .posts-items li:nth-child(n + 2) .post-thumb img {
					max-width: 110px;
				}
			';
			break;
			
		case 'ad':
			$out = '
				@media (max-width: 767px) {
					.stream-item-mag .container-wrapper {
						padding: 5px 0 !important;
						border-radius: 0;
						border: 0;
						box-shadow: none;
					}
				}

				.stream-item-mag.stream-item.half-box .stream-item {
					margin: 0;
				}

				.stream-item-mag.stream-item.half-box .adsbygoogle {
					width: 300px !important;
					min-height: 250px !important;
					margin: 0 auto;
				}

				@media (max-width: 991px) {
					.stream-item-mag.content-only {
						margin: 15px 0;
					}
				}
			';
			break;

		case 'breaking':
			$out = '
				.breaking-news-outer {
					height: 40px;
					overflow: hidden;
					border-radius: 2px;
				}

				.mag-box .breaking-title {
					line-height: 40px;
					margin-top: -1px;
					padding-left: 20px;
					padding-right: 20px;
				}

				.mag-box .breaking {
					height: 40px;
					background-color: #ffffff;
					border: 1px solid rgba(0, 0, 0, 0.1);
					border-left-width: 0;
				}

				.mag-box .controls-is-active .ticker-wrapper.has-js {
					padding-right: 90px;
				}

				.mag-box .ticker-wrapper.has-js,
				.mag-box .ticker,
				.mag-box .ticker-content,
				.mag-box .ticker-swipe,
				.mag-box .breaking-news-nav,
				.mag-box .breaking-news-nav li {
					line-height: 38px;
					height: 38px;
				}

				.mag-box .breaking-news-nav {
					padding-right: 0;
				}

				.mag-box .breaking-news-nav li {
					margin: 0;
					width: 38px;
					border-width: 0 0 0 1px;
					border-radius: 0;
					font-size: 16px;
				}

				.mag-box .breaking-news-nav li:hover {
					border-color: transparent !important;
				}

				.mag-box .pages-nav {
					padding-top: 20px;
				}
			';
			break;


		case 'first_big':
			$out = '
				@media (min-width: 671px) {
					.miscellaneous-box li:first-child .post-title {
						font-size: 36px;
						line-height: 1.2;
					}
				}

				.miscellaneous-box li:not(:first-child) .post-thumb {
					margin: 0 0 5px !important;
				}

				.miscellaneous-box .posts-items li {
					width: calc(100% / 3);
					margin-top: 30px;
				}

				.miscellaneous-box .posts-items li:first-child {
					width: 96%;
					padding: 0;
					margin: 0 2%;
					position: relative;
				}

				@media (min-width: 480px) {
					.miscellaneous-box .posts-items li:first-child {
						min-height: 180px;
						background-color: rgba(0, 0, 0, 0.2);
					}
				}

				.miscellaneous-box .posts-items li:nth-child(3n + 2) {
					clear: both;
				}

				@media (max-width: 670px) {
					.miscellaneous-box .posts-items li {
						width: 50%;
					}
					.miscellaneous-box .posts-items li:nth-child(3n + 2) {
						clear: none;
					}
					.miscellaneous-box .posts-items li:nth-child(2n + 2) {
						clear: both;
					}
					.miscellaneous-box li:first-child .post-content {
						padding: 10px 15px;
					}
					.miscellaneous-box li:first-child .tie-media-icon {
						left: 10px;
						top: 10px;
						-webkit-transform: none;
								-ms-transform: none;
										transform: none;
					}
					.miscellaneous-box li:first-child .tie-media-icon:before {
						width: 35px;
						height: 35px;
						line-height: 30px;
					}
					.miscellaneous-box li:first-child.is-trending .tie-media-icon {
						left: 50px;
					}
				}

				@media (max-width: 479px) {
					.miscellaneous-box li:first-child .post-title {
						font-size: 18px;
						max-height: 2.4em;
						overflow: hidden;
					}
					.miscellaneous-box li:first-child .post-meta {
						max-height: 2em;
					}
					.miscellaneous-box li:first-child .trending-post,
					.miscellaneous-box li:first-child .post-cat,
					.miscellaneous-box li:first-child .post-rating,
					.miscellaneous-box li:first-child .digital-rating,
					.miscellaneous-box li:first-child .tie-media-icon {
						display: none;
					}
				}

				@media (max-width: 380px) {
					.miscellaneous-box .posts-items li {
						width: 100%;
					}
				}

				@media (min-width: 992px) {
					.full-width .miscellaneous-box .posts-items {
						margin: 0 -1.33%;
					}
					.full-width .miscellaneous-box .posts-items li:first-child {
						margin: 0 1.33%;
						width: 97.34%;
					}
					.full-width .miscellaneous-box .posts-items li:not(:first-child) {
						width: 25%;
						padding: 0 1.33%;
					}
					.full-width .miscellaneous-box .posts-items li:nth-child(3n + 2) {
						clear: none;
					}
					.full-width .miscellaneous-box .posts-items li:nth-child(4n + 2) {
						clear: left;
					}
				}
			';
			break;

		case 'videos_list':
			$out = '
				.video-playlist-wrapper {
					background-color: #27292d;
					position: relative;
					width: 66%;
					height: 434px;
					float: left;
				}
				
				.video-playlist-wrapper .loader-overlay {
					z-index: 1;
				}
				
				.video-playlist-wrapper iframe {
					height: 434px;
					width: 100%;
				}
				
				.video-player-wrapper {
					position: relative;
					z-index: 2;
				}
				
				.video-frame {
					visibility: hidden;
				}
				
				.video-playlist-nav-wrapper {
					width: 34%;
					float: right;
					height: 434px;
					overflow: hidden;
					background: #ffffff;
					position: relative;
					border-width: 0 1px 1px 0;
				}
				
				.video-playlist-nav-wrapper:after {
					content: "";
					position: absolute;
					right: 0;
					top: 0;
					height: 100%;
					width: 1px;
					background: rgba(0, 0, 0, 0.05);
				}
				
				.video-playlist-nav-wrapper:before {
					content: "";
					position: absolute;
					right: 0;
					background: rgba(0, 0, 0, 0.05);
					width: 100%;
					height: 1px;
					bottom: 0;
					top: auto;
				}
				
				.video-playlist-nav-wrapper .mCustomScrollBox > .mCSB_scrollTools {
					right: 0;
					left: auto;
				}
				
				.playlist-title {
					background: var(--brand-color);
					color: var(--bright-color);
					height: 70px;
					width: 100%;
					padding: 0 15px;
					line-height: 17px;
					z-index: 9;
				}
				
				.playlist-title h2 {
					padding-top: 14px;
					font-size: 18px;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
				}
				
				.videos-number {
					font-size: 11px;
					display: block;
					float: left;
				}
				
				.playlist-title-icon {
					font-size: 27px;
					float: left;
					margin-right: 10px;
					height: 70px;
					line-height: 70px;
					width: 40px;
					text-align: center;
					font-weight: normal;
				}
				
				.video-playlist-nav {
					position: relative;
					height: 434px;
					clear: both;
				}
				
				.is-mobile .video-playlist-nav {
					overflow-y: auto;
				}
				
				.video-playlist-nav:not(.playlist-has-title) {
					border-top: 1px solid rgba(0, 0, 0, 0.05);
				}
				
				.playlist-has-title {
					height: 364px;
				}
				
				.video-playlist-item {
					padding: 12px 15px;
					display: block;
					overflow: hidden;
					cursor: pointer;
					border-bottom: 1px solid rgba(0, 0, 0, 0.05);
					transition: 0.3s;
				}
				
				.video-playlist-item:last-of-type {
					border-bottom: 0;
				}
				
				.video-playlist-item h2 {
					font-size: 12px;
					font-weight: normal;
					line-height: 17px;
				}
				
				.video-playlist-item:hover,
				.is-playing {
					background: #F7F7F7;
				}
				
				.video-paused-icon,
				.video-play-icon,
				.video-number {
					float: left;
					width: 20px;
					text-align: left;
					line-height: 46px;
					font-size: 11px;
					color: var(--base-color);
				}
				
				.video-play-icon {
					display: none;
					color: var(--brand-color);
				}
				
				.is-playing .video-number,
				.is-paused .video-number,
				.video-paused-icon {
					display: none;
				}
				
				.is-playing .video-play-icon,
				.is-paused .video-paused-icon {
					display: block;
				}
				
				.video-thumbnail {
					width: 75px;
					height: 42px;
					background-repeat: no-repeat;
					background-position: center center;
					background-size: cover;
					float: left;
				}
				
				.video-info {
					padding-left: 105px;
				}
				
				.video-duration {
					float: left;
					font-size: 11px;
					color: #767676;
					margin-top: 3px;
					line-height: 1;
				}
				
				@media only screen and (min-width: 768px) and (max-width: 991px) {
					.video-playlist-nav-wrapper,
					.video-playlist-wrapper,
					.video-playlist-wrapper iframe {
						height: 383px;
					}
					.video-playlist-nav {
						height: 383px !important;
					}
					.playlist-has-title {
						height: 313px !important;
					}
				}
				
				@media (max-width: 767px) {
					.video-playlist-wrapper {
						width: 100%;
						height: auto;
					}
					.video-playlist-wrapper iframe {
						position: absolute;
						top: 0;
						left: 0;
						width: 100%;
						height: 100%;
					}
					.video-player-wrapper {
						position: relative;
						padding-bottom: 56.25%;
						height: 0;
					}
					.video-playlist-nav-wrapper {
						height: auto !important;
						width: 100%;
					}
					.video-playlist-nav {
						height: 270px !important;
					}
					.playlist-has-title {
						height: 244px !important;
					}
				}
				
				@media (min-width: 992px) {
					.has-builder .has-sidebar .video-playlist-nav-wrapper,
					.has-builder .has-sidebar .video-playlist-nav,
					.has-builder .has-sidebar .video-playlist-wrapper,
					.has-builder .has-sidebar .video-playlist-wrapper iframe {
						height: 323px !important;
					}
					.has-builder .has-sidebar .playlist-has-title {
						height: 263px !important;
					}
					.has-builder .has-sidebar .playlist-title {
						height: 60px;
					}
					.has-builder .has-sidebar .playlist-title h2 {
						padding-top: 11px;
					}
					.has-builder .has-sidebar .playlist-title-icon {
						height: 60px;
						line-height: 60px;
					}
				}
			';
			break;

		case 'timeline':
			$out = '
				.timeline-box .posts-items {
					position: relative;
					overflow: hidden;
				}

				.timeline-box .posts-items::before, .timeline-box .posts-items:last-of-type:after {
					content: "";
					width: 2px;
					height: 100%;
					background: rgba(0, 0, 0, 0.1);
					position: absolute;
					left: 29px;
					z-index: 0;
				}

				.timeline-box .posts-items:last-of-type:after {
					background-image: linear-gradient(to bottom, #e5e5e5 0%, #ffffff 80%);
					height: 150px;
					bottom: 0;
				}

				.timeline-box .posts-items li {
					display: block !important;
				}

				@media (max-width: 580px) {
					.timeline-box .posts-items li .post-thumb {
						float: none;
					}
				}

				.timeline-box .posts-items-loaded-ajax {
					margin-top: 0 !important;
				}

				.timeline-box .posts-items-loaded-ajax li:first-child {
					padding-top: 30px;
				}

				.timeline-box .year-month {
					background: #e6e6e6;
					color: #2c2f34;
					text-align: center;
					width: 60px;
					height: 60px;
					line-height: 18px;
					float: left;
					margin: 0 10px 10px 0;
					position: relative;
					overflow: hidden;
					z-index: 1;
					padding-top: 12px;
					border-radius: 100%;
				}

				.timeline-box .year-month span {
					font-weight: 600;
					font-size: 14px;
				}

				.timeline-box .year-month em {
					display: block;
					font-size: 80%;
					padding-top: 1px;
					opacity: 0.7;
				}

				.timeline-box .day-month {
					margin-bottom: 10px;
					padding-left: 50px;
					position: relative;
					z-index: 2;
				}

				.timeline-box .day-month::before {
					position: absolute;
					left: 23px;
					top: 3px;
					content: "";
					width: 14px;
					height: 14px;
					border-radius: 50%;
					background: #e6e6e6;
					border: 3px solid #ffffff;
					z-index: 1;
				}

				.timeline-box .post-item-inner {
					margin-left: 50px;
					display: -webkit-flex;
					display: -ms-flexbox;
					display: flex;
				}

				@media (max-width: 580px) {
					.timeline-box .post-item-inner {
						-webkit-flex-direction: column;
								-ms-flex-direction: column;
										flex-direction: column;
					}
				}
			';
			break;

		case 'mini':
			$out = '			
				.mini-posts-box .posts-items li .post-title {
					font-size: 18px;
					margin-bottom: 10px;
				}

				.mini-posts-box .posts-items li .post-thumb {
					float: left;
					margin-right: 15px;
				}

				.mini-posts-box .posts-items li .post-thumb img {
					max-width: 110px;
				}

				.mini-posts-box .posts-items li:nth-child(2n + 1) {
					clear: left;
				}

				@media only screen and (min-width: 992px) and (max-width: 1100px), only screen and (max-width: 767px) {
					.mini-posts-box .posts-items li {
						width: 100%;
					}
					.mini-posts-box .posts-items li:nth-child(n + 2) {
						margin-top: 24px;
					}
				}

				@media (min-width: 992px) {
					.full-width .mini-posts-box .posts-items li:nth-child(-n + 3) {
						margin-top: 0;
					}
					.full-width .mini-posts-box .posts-items li:nth-child(n) {
						width: calc(100% / 3);
						clear: none;
					}
					.full-width .mini-posts-box .posts-items li:nth-child(3n + 1) {
						clear: left;
					}
				}
			';
			break;

		case 'big':
			$out = '
				@media (max-width: 670px) {
					.big-posts-box .posts-items li {
						width: 100%;
					}
				}

				.big-posts-box .posts-items li .post-thumb {
					margin-right: 0;
					float: none !important;
					margin-bottom: 10px;
				}

				.big-posts-box .posts-items li .post-details {
					padding-left: 0;
				}

				.big-posts-box .posts-items li .post-title {
					font-size: 20px;
					padding-left: 0;
				}

				.big-posts-box .posts-items li:nth-child(2n + 1) {
					clear: left;
				}

				@media (min-width: 670px) {
					.full-width .big-posts-box .posts-items {
						margin: 0 -1.35%;
					}
					.full-width .big-posts-box .posts-items li {
						width: calc(100% / 3);
						padding: 0 1.35%;
					}
					.full-width .big-posts-box .posts-items li:nth-child(-n + 3) {
						margin-top: 0;
					}
					.full-width .big-posts-box .posts-items li:nth-child(2n + 1) {
						clear: none;
					}
					.full-width .big-posts-box .posts-items li:nth-child(3n + 1) {
						clear: left;
					}
				}
			';
			break;
	}

	return apply_filters( 'TieLabs/inline_styles/blocks', $out, $id );
}
