<?php
/**
 * Widgets Inline Styles
 *
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly

require TIELABS_TEMPLATE_PATH . '/inc//inline-styles/block-heads.php';
require TIELABS_TEMPLATE_PATH . '/inc//inline-styles/widgets.php';


/**
 * Inline Widgets Styles
 */
add_action( 'dynamic_sidebar', 'tie_inline_styles_widgets' );
function tie_inline_styles_widgets( $widget = array() ){
	
	if( is_admin() || empty( $widget['callback'][0]->id_base ) || isset( $GLOBALS['has_cached_inline_css'] ) ){
		return false;
	}

	if( empty( $GLOBALS['tie_inline_styles'] ) ){
		$GLOBALS['tie_inline_styles'] = array();
	}

	$id = $widget['callback'][0]->id_base;

	$widgets_dependency = array();

	$dependency   = ! empty( $widgets_dependency[ $id ] ) ? $widgets_dependency[ $id ] : array();

	if( $id == 'posts-list-widget' ){
		
		$widget_number  = $widget['params'][0]['number'];
		$widget_options = get_option( 'widget_' . $id );
		$widget_options = $widget_options[ $widget_number ];
		$widget_style   = ! empty( $widget_options[ 'style' ] ) ? $widget_options[ 'style' ] : false;
		
		if( $widget_style == 7 || $widget_style == 2 ){
			$dependency[] = 'posts-list-widget-'. $widget_style;
		}
	}

	$dependency[] = $id;

	$out = '';
	
	foreach ( $dependency as $css_id ) {
		if( empty( $GLOBALS['tie_inline_styles'][ "widget_$css_id" ] ) ){

			$this_css = tie_get_inline_widgets_styles( $css_id );
			if( ! empty( $this_css ) ){
				$GLOBALS['tie_inline_styles'][ "widget_$css_id" ] = $this_css;
				$out .= $this_css;
			}
		}
	}

	if( ! empty( $out ) ) {
		TIELABS_STYLES::print_inline_css( $out );
	}
}

/**
 * Inline Blocks Styles
 */
add_action( 'TieLabs/Builder/before_block', 'tie_inline_styles_blocks' );
function tie_inline_styles_blocks( $block = array() ){

	if( empty( $block['style'] ) || isset( $GLOBALS['has_cached_inline_css'] ) ){
		return false;
	}
	
	if( empty( $GLOBALS['tie_inline_styles'] ) ){
		$GLOBALS['tie_inline_styles'] = array();
	}

	// Include the styles file when it needed
	if( ! function_exists( 'tie_get_inline_blocks_styles' ) ){
		require TIELABS_TEMPLATE_PATH . '/inc//inline-styles/blocks.php';
	}

	$id = $block['style'];

	$blocks = array(
		'tabs'      => array( 'li' ),
		'big_thumb' => array( 'li', 'first-post-gradient' ),
		'first_big' => array( 'first-post-gradient' ),
		'row'       => array( 'grid' ),
		'scroll_2'  => array( 'scroll' ),
		'2c'        => array( 'half_box' ),
		'code_50'   => array( 'half_box' ),	
		'ad_50'     => array( 'half_box', 'ad' ),	
		'timeline'      => array( 'default' ),	
		'classic-small' => array( 'default' ),
		'content'       => array( 'full_thumb' ),
		'overlay-title' => array( 'full_thumb' ),
		'overlay-title-center' => array( 'full_thumb', 'overlay-title' ),
	);


	$dependency   = ! empty( $blocks[ $id ] ) ? $blocks[ $id ] : array();
	$dependency[] = $id;

	$out = '';
	
	foreach ( $dependency as $css_id ) {
		if( empty( $GLOBALS['tie_inline_styles'][ "block_$css_id" ] ) ){

			$this_css = tie_get_inline_blocks_styles( $css_id );
			if( ! empty( $this_css ) ){
				$GLOBALS['tie_inline_styles'][ "block_$css_id" ] = $this_css;
				$out .= $this_css;
			}
		}
	}

	if( ! empty( $out ) ) {
		TIELABS_STYLES::print_inline_css( $out );
	}
}


/**
 * Inline Sliders Styles
 */
add_action( 'TieLabs/Builder/before_slider', 'tie_inline_styles_sliders' );
function tie_inline_styles_sliders( $id = false ){

	if( empty( $id ) || isset( $GLOBALS['has_cached_inline_css'] ) ){
		return false;
	}

	if( empty( $GLOBALS['tie_inline_styles'] ) ){
		$GLOBALS['tie_inline_styles'] = array();
	}

	// Include the styles file when it needed
	if( ! function_exists( 'tie_get_inline_sliders_styles' ) ){
		require TIELABS_TEMPLATE_PATH . '/inc//inline-styles/sliders.php';
	}
	
	$sliders = array(
		1  => array( 'wide' ),
		3  => array( 'wide', 'centered-title' ),
		4  => array( 'wide', 'centered-title', 'with-nav' ),
		50 => array( 'wide', 'with-nav' ),
	);
	
	$dependency = ! empty( $sliders[ $id ] ) ? $sliders[ $id ] : array();

	// Boxed Sliders Common
	if( $id >= 5 && $id <= 17 ){
		$dependency[] = 'boxed';

		// Grid Sliders Common
		if( $id >= 9 && $id <= 17 ){
			
			$dependency[] = 'grid';

			if( $id == 10 || $id == 17 ){
				$dependency[] = 'slider-10-17';
			}

			if( $id == 13 || $id == 14 ){
				$dependency[] = $id;

				$dependency[] = 'slider-13-14';
			}
		} // Grid
	} // Boxed

	if( $id != 13 && $id != 14 ){
		$dependency[] = $id;
	}

	$out = '';
	
	foreach ( $dependency as $css_id ) {
		if( empty( $GLOBALS['tie_inline_styles'][ "slider_$css_id" ] ) ){

			$this_css = tie_get_inline_sliders_styles( $css_id );
			if( ! empty( $this_css ) ){
				$GLOBALS['tie_inline_styles'][ "slider_$css_id" ] = $this_css;
				$out .= $this_css;
			}
		}
	}

	if( ! empty( $out ) ) {
		TIELABS_STYLES::print_inline_css( $out );
	}
}



/**
 * General Inline Styles
 */
function tie_inline_styles_general( $id = false ){

	if( empty( $id ) || isset( $GLOBALS['has_cached_inline_css'] ) ){
		return false;
	}

	if( empty( $GLOBALS['tie_inline_styles'] ) ){
		$GLOBALS['tie_inline_styles'] = array();
	}

	// Include the styles file when it needed
	if( ! function_exists( 'tie_get_inline_general_styles' ) ){
		require TIELABS_TEMPLATE_PATH . '/inc//inline-styles/general.php';
	}
	
	$styles = array();
	
	$dependency = ! empty( $styles[ $id ] ) ? $styles[ $id ] : array();
	$dependency[] = $id;

	$out = '';
	
	foreach ( $dependency as $css_id ) {
		if( empty( $GLOBALS['tie_inline_styles'][ "general_$css_id" ] ) ){

			$this_css = tie_get_inline_general_styles( $css_id );
			if( ! empty( $this_css ) ){
				$GLOBALS['tie_inline_styles'][ "general_$css_id" ] = $this_css;
				$out .= $this_css;
			}
		}
	}

	if( ! empty( $out ) ) {
		TIELABS_STYLES::print_inline_css( $out );
	}
}


// 
add_action( 'TieLabs/Weather/before', 'tie_inline_styles_weather' );
function tie_inline_styles_weather(){
	tie_inline_styles_general( 'weather' );
}

// 
add_action( 'TieLabs/archives/before', 'tie_inline_styles_archives', 10, 3 );
function tie_inline_styles_archives( $layout = false, $template = false, $args = array() ){
	
	// Match the name of the layouts to the builder blocks
	if( $layout == 'excerpt' ){
		$layout = 'default';
	}
	elseif( $layout == 'full-thumb' ){
		$layout = 'full_thumb';
	}
	elseif( $layout == 'first-big' ){
		$layout = 'first_big';
	}

	tie_inline_styles_blocks( array( 'style' => $layout ) );
}



/* WP Footer */
/*
add_action( 'wp_footer', 'tie_inline_styles_save_cache_home', 100 );
function tie_inline_styles_save_cache_home(){

	if( empty( $GLOBALS['tie_inline_styles'] ) || ! is_array( $GLOBALS['tie_inline_styles'] ) ){
		return;
	}	

	if( ( is_home() || is_front_page() ) && class_exists( 'JANNAH_OPTIMIZATION_GENERAL' ) ){
		$home_styles_key    = apply_filters( 'TieLabs/cache_key', '-home-inline-styles' );
		$stored_home_styles = get_transient( $home_styles_key );
		if( false ===  $stored_home_styles ){
			$home_styles = implode( ' ', $GLOBALS['tie_inline_styles'] );
			set_transient( $home_styles_key, $home_styles );
		}
	}
}
*/



/* WP Head */
/*
add_action( 'wp_head', 'tie_inline_styles_print_cache_home', 20 );
function tie_inline_styles_print_cache_home(){

	if( ( is_home() || is_front_page() ) && class_exists( 'JANNAH_OPTIMIZATION_GENERAL' ) ){
		$home_styles_key    = apply_filters( 'TieLabs/cache_key', '-home-inline-styles' );
		$stored_home_styles = get_transient( $home_styles_key );

		if( ! empty( $stored_home_styles ) ) {
			TIELABS_STYLES::print_inline_css( $stored_home_styles );
			$GLOBALS['has_cached_inline_css'] = true;
		}

	}
}
*/