<?php
/**
 * Blocks Head Style
 *
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly

add_action( 'wp_head', 'tie_inline_blocks_head', 5 );
function tie_inline_blocks_head(){

	// Blocks Style
	$block_style = tie_get_option( 'blocks_style', 1 );

	$out = '';

	if( $block_style == 4 || $block_style == 5 || $block_style == 6 ){

		$out .= '
			.block-head-4 .has-block-head-4,
			.block-head-4 .mag-box-title h3,
			.block-head-4 .comment-reply-title,
			.block-head-4 .related.products > h2,
			.block-head-4 .up-sells > h2,
			.block-head-4 .cross-sells > h2,
			.block-head-4 .cart_totals > h2,
			.block-head-4 .bbp-form legend {
				position: relative;
				opacity: 0.99;
				display: inline-block !important;
				width: auto;
				font-size: 15px;
				line-height: 1.3;
				font-weight: 500;
				margin-bottom: 20px;
				padding: 5px 10px;
				color: var(--bright-color);
			}

			.block-head-4 .has-block-head-4:before,
			.block-head-4 .mag-box-title h3:before,
			.block-head-4 .comment-reply-title:before,
			.block-head-4 .related.products > h2:before,
			.block-head-4 .up-sells > h2:before,
			.block-head-4 .cross-sells > h2:before,
			.block-head-4 .cart_totals > h2:before,
			.block-head-4 .bbp-form legend:before {
				content: "";
				position: absolute;
				left: 0;
				top: 0;
				width: 100%;
				height: 100%;
				background-color: var(--brand-color);
				z-index: -1;
			}

			.block-head-4 .section-title-default {
				padding: 5px 20px;
			}

			.block-head-4 .mag-box-title h3 a,
			.block-head-4 .section-title-default a,
			.block-head-4 #cancel-comment-reply-link {
				color: var(--bright-color);
			}

			.block-head-4 .mag-box-title h3 a:hover,
			.block-head-4 .section-title-default a:hover,
			.block-head-4 #cancel-comment-reply-link:hover {
				opacity: 0.8;
			}

			.block-head-4 .mag-box-title {
				position: relative;
				margin-bottom: 0;
			}

			.block-head-4 .mag-box-title h3 {
				font-size: 18px;
			}

			.block-head-4 .mag-box-title .tie-alignright {
				margin-top: 6px;
			}

			.block-head-4 .widget-title {
				padding: 0 10px;
			}

			.block-head-4 .widget-title .the-subtitle {
				line-height: 27px;
			}

			.block-head-4#tie-body .widget-title,
			.block-head-4#tie-body .widget-title a:not(:hover) {
				color: #ffffff;
			}

			.block-head-4#tie-body .widget-title:before {
				background: #111;
			}

			.block-head-4 #check-also-box .widget-title {
				padding-left: 30px;
			}

			.block-head-4 #check-also-close {
				top: 4px;
				left: 5px;
			}

			.block-head-4 .widget-title a:not(:hover) {
				color: #ffffff;
			}

			.block-head-4 .mag-box-filter-links .flexMenu-popup {
				top: 5px;
			}

			.block-head-4 span.widget-title-icon {
				float: left;
				margin-right: 10px;
				line-height: 27px;
				position: static;
				color: #ffffff;
			}

			.block-head-4 .mag-box > .container-wrapper,
			.block-head-4 .widget-title,
			.block-head-4 #footer .widget,
			.block-head-4 .side-aside .widget {
				opacity: 0.99;
			}

			.block-head-4.magazine2 .tabs {
				border: 1px solid var(--brand-color);
				border-radius: 2px;
				max-height: 40px;
			}

			.block-head-4.magazine2 .tabs > li > a {
				line-height: 38px;
				border-width: 0;
				padding: 0 20px;
			}

			.block-head-4.magazine2 .tabs li a {
				color: var(--brand-color);
				background-color: transparent;
			}

			.block-head-4.magazine2 .tabs li a:hover {
				color: var(--dark-brand-color);
			}

			.block-head-4.magazine2 .tabs.tabs li.active a {
				color: var(--bright-color);
				background-color: var(--brand-color);
			}

			.block-head-4.magazine2 .tabs .flexMenu-popup {
				border-color: var(--brand-color);
				-webkit-transform: translateY(0px) translateX(1px);
						-ms-transform: translateY(0px) translateX(1px);
								transform: translateY(0px) translateX(1px);
			}

			.block-head-4.magazine2 .tabs .flexMenu-popup a {
				padding-top: 6px;
				padding-bottom: 6px;
				border-bottom-width: 0;
			}

			html:not(.dark-skin) .block-head-4.magazine2 .section-item:not(.dark-skin) .box-dark-skin.tabs-box .tabs {
				border-width: 0 0 1px;
				max-height: 50px;
				border-radius: 0;
			}

			html:not(.dark-skin) .block-head-4.magazine2 .section-item:not(.dark-skin) .box-dark-skin.tabs-box .tabs > li > a {
				line-height: 48px;
			}

			html:not(.dark-skin) .block-head-4.magazine2 .section-item:not(.dark-skin) .box-dark-skin.tabs-box .tabs .flexMenu-popup {
				-webkit-transform: none;
						-ms-transform: none;
								transform: none;
			}
		';
	}

	switch( $block_style ){

		case '1':
			$out .= '
				.block-head-1 .the-global-title,
				.block-head-1 .comment-reply-title,
				.block-head-1 .related.products > h2,
				.block-head-1 .up-sells > h2,
				.block-head-1 .cross-sells > h2,
				.block-head-1 .cart_totals > h2,
				.block-head-1 .bbp-form legend {
					position: relative;
					font-size: 17px;
					padding: 0 0 15px;
					border-bottom: 2px solid rgba(0, 0, 0, 0.1);
					margin-bottom: 20px;
				}

				.block-head-1 .the-global-title:after,
				.block-head-1 .comment-reply-title:after,
				.block-head-1 .related.products > h2:after,
				.block-head-1 .up-sells > h2:after,
				.block-head-1 .cross-sells > h2:after,
				.block-head-1 .cart_totals > h2:after,
				.block-head-1 .bbp-form legend:after {
					content: "";
					background: #2c2f34;
					width: 40px;
					height: 2px;
					position: absolute;
					bottom: -2px;
					left: 0;
				}

				.dark-skin .block-head-1 .the-global-title:after, .dark-skin
				.block-head-1 .comment-reply-title:after, .dark-skin
				.block-head-1 .related.products > h2:after, .dark-skin
				.block-head-1 .up-sells > h2:after, .dark-skin
				.block-head-1 .cross-sells > h2:after, .dark-skin
				.block-head-1 .cart_totals > h2:after, .dark-skin
				.block-head-1 .bbp-form legend:after {
					background: #ffffff;
				}

				.block-head-1 .the-global-title:before,
				.block-head-1 .comment-reply-title:before,
				.block-head-1 .related.products > h2:before,
				.block-head-1 .up-sells > h2:before,
				.block-head-1 .cross-sells > h2:before,
				.block-head-1 .cart_totals > h2:before,
				.block-head-1 .bbp-form legend:before {
					content: "";
					width: 0;
					height: 0;
					position: absolute;
					bottom: -5px;
					left: 0;
					border-left: 0;
					border-right: 5px solid transparent;
					border-top: 5px solid #2c2f34;
				}

				.dark-skin .block-head-1 .the-global-title:before, .dark-skin
				.block-head-1 .comment-reply-title:before, .dark-skin
				.block-head-1 .related.products > h2:before, .dark-skin
				.block-head-1 .up-sells > h2:before, .dark-skin
				.block-head-1 .cross-sells > h2:before, .dark-skin
				.block-head-1 .cart_totals > h2:before, .dark-skin
				.block-head-1 .bbp-form legend:before {
					border-top-color: #ffffff;
				}

				.block-head-1 .mag-box div.mag-box-title:before {
					border-top-color: var(--brand-color);
				}

				.block-head-1 .dark-skin .section-title-default:after {
					background: #ffffff;
				}

				.block-head-1 .dark-skin .section-title-default:before {
					border-top-color: #ffffff;
				}

				.block-head-1 .dark-skin .widget-title:after {
					background: #ffffff;
				}

				.block-head-1 .dark-skin .widget-title:before {
					border-top-color: #ffffff;
				}

				.block-head-1 #footer .widget-title:before {
					display: none;
				}

				.block-head-1 #footer .widget-title {
					border-bottom: 0;
				}

				.dark-skin .block-head-1 .the-global-title:after,
				.dark-skin .block-head-1 .related.products > h2:after,
				.dark-skin .block-head-1 .up-sells > h2:after,
				.dark-skin .block-head-1 .cross-sells > h2:after,
				.dark-skin .block-head-1 .cart_totals > h2:after,
				.dark-skin .block-head-1 .bbp-form legend:after {
					background: #ffffff;
				}

				.block-head-1 .mag-box div.mag-box-title,
				.block-head-1 .mag-box-title h3 a,
				.block-head-1 .block-more-button {
					color: var(--brand-color);
				}

				.block-head-1 .mag-box-title h3 a:hover,
				.block-head-1 .block-more-button:hover {
					color: var(--dark-brand-color);
				}

				.block-head-1 .mag-box div.mag-box-title:after {
					background: var(--brand-color);
				}

				.block-head-1 .dark-skin .the-global-title,
				.dark-skin .block-head-1 .the-global-title,
				.dark-skin .block-head-1 .related.products > h2,
				.dark-skin .block-head-1 .up-sells > h2,
				.dark-skin .block-head-1 .cross-sells > h2,
				.dark-skin .block-head-1 .cart_totals > h2,
				.dark-skin .block-head-1 .bbp-form legend {
					color: #ffffff;
					border-bottom-color: rgba(255, 255, 255, 0.1);
				}
			';
			break;

		case '2':
			$out .= '
				.block-head-2 .the-global-title,
				.block-head-2 .comment-reply-title,
				.block-head-2 .related.products > h2,
				.block-head-2 .up-sells > h2,
				.block-head-2 .cross-sells > h2,
				.block-head-2 .cart_totals > h2,
				.block-head-2 .bbp-form legend {
					position: relative;
					font-size: 17px;
					padding: 0 0 15px;
					margin-bottom: 20px;
					border-bottom: 3px solid var(--brand-color);
					color: var(--brand-color);
				}

				.block-head-2 .section-title-default {
					border-bottom-width: 5px;
				}

				.block-head-2 #footer .widget-title:after {
					content: "";
					background: #ffffff;
					width: 40px;
					height: 2px;
					position: absolute;
					bottom: -2px;
					left: 0;
				}

				.block-head-2 #footer .widget-title {
					border-bottom: 0;
				}

				.block-head-2 .dark-skin .the-global-title,
				.dark-skin .block-head-2 .the-global-title,
				.dark-skin .block-head-2 .related.products > h2,
				.dark-skin .block-head-2 .up-sells > h2,
				.dark-skin .block-head-2 .cross-sells > h2,
				.dark-skin .block-head-2 .cart_totals > h2,
				.dark-skin .block-head-2 .bbp-form legend {
					color: #ffffff;
					border-bottom-color: rgba(255, 255, 255, 0.1);
				}
			';
			break;

		case '3':
			$out .= '
				.block-head-3 .the-global-title,
				.block-head-3 .comment-reply-title,
				.block-head-3 .related.products > h2,
				.block-head-3 .up-sells > h2,
				.block-head-3 .cross-sells > h2,
				.block-head-3 .cart_totals > h2,
				.block-head-3 .bbp-form legend {
					position: relative;
					font-size: 17px;
					margin-bottom: 20px;
					border-bottom: 1px solid rgba(0, 0, 0, 0.1);
					padding: 0 0 14px;
				}

				.block-head-3 .the-global-title:after,
				.block-head-3 .comment-reply-title:after,
				.block-head-3 .related.products > h2:after,
				.block-head-3 .up-sells > h2:after,
				.block-head-3 .cross-sells > h2:after,
				.block-head-3 .cart_totals > h2:after,
				.block-head-3 .bbp-form legend:after {
					content: "";
					background: #27292d;
					width: 80px;
					height: 3px;
					position: absolute;
					bottom: -1px;
					left: 0;
				}

				.block-head-3 .dark-skin .the-global-title:after {
					background: #ffffff;
				}

				.block-head-3 #footer .widget-title:after {
					width: 50px;
				}

				.block-head-3 #footer .widget-title {
					border-bottom: 0;
				}

				.dark-skin .block-head-3 .the-global-title:after,
				.dark-skin .block-head-3 .related.products > h2:after,
				.dark-skin .block-head-3 .up-sells > h2:after,
				.dark-skin .block-head-3 .cross-sells > h2:after,
				.dark-skin .block-head-3 .cart_totals > h2:after,
				.dark-skin .block-head-3 .bbp-form legend:after {
					background: #ffffff;
				}

				.block-head-3 .mag-box div.mag-box-title,
				.block-head-3 .mag-box-title h3 a,
				.block-head-3 .block-more-button {
					color: var(--brand-color);
				}

				.block-head-3 .mag-box-title h3 a:hover,
				.block-head-3 .block-more-button:hover {
					color: var(--dark-brand-color);
				}

				.block-head-3 .mag-box div.mag-box-title:after {
					background: var(--brand-color);
				}

				.block-head-3 .dark-skin .the-global-title,
				.dark-skin .block-head-3 .the-global-title,
				.dark-skin .block-head-3 .related.products > h2,
				.dark-skin .block-head-3 .up-sells > h2,
				.dark-skin .block-head-3 .cross-sells > h2,
				.dark-skin .block-head-3 .cart_totals > h2,
				.dark-skin .block-head-3 .bbp-form legend {
					color: #ffffff;
					border-bottom-color: rgba(255, 255, 255, 0.1);
				}
			';
			break;

		case '5':
			$out .= '
				.block-head-5 .has-block-head-4,
				.block-head-5 .mag-box-title h3,
				.block-head-5 .comment-reply-title,
				.block-head-5 .related.products > h2,
				.block-head-5 .up-sells > h2,
				.block-head-5 .cross-sells > h2,
				.block-head-5 .cart_totals > h2,
				.block-head-5 .bbp-form legend {
					padding: 5px 15px 5px 25px;
				}

				.block-head-5 .has-block-head-4:before,
				.block-head-5 .mag-box-title h3:before,
				.block-head-5 .comment-reply-title:before,
				.block-head-5 .related.products > h2:before,
				.block-head-5 .up-sells > h2:before,
				.block-head-5 .cross-sells > h2:before,
				.block-head-5 .cart_totals > h2:before,
				.block-head-5 .bbp-form legend:before {
					-webkit-transform: skew(-20deg) translateX(6px);
							-ms-transform: skew(-20deg) translateX(6px);
									transform: skew(-20deg) translateX(6px);
				}

				.block-head-5 .section-title-default {
					padding: 5px 20px 5px 35px;
				}

				.block-head-5 .section-title-default:before {
					-webkit-transform: skew(-20deg) translateX(13px);
							-ms-transform: skew(-20deg) translateX(13px);
									transform: skew(-20deg) translateX(13px);
				}

				.block-head-5 .widget-title {
					padding: 0 10px 0 20px;
				}

				.block-head-5 #check-also-box .widget-title {
					padding-left: 37px;
				}

				.block-head-5 #check-also-close {
					left: 12px;
				}

				.block-head-5.magazine2 .tabs > .active a {
					background-color: transparent !important;
					position: relative;
				}

				.block-head-5.magazine2 .tabs > .active a:before {
					content: "";
					position: absolute;
					z-index: -1;
					width: 100%;
					height: 100%;
					top: 0;
					left: 0;
					background-color: var(--brand-color);
					-webkit-transform: skew(-20deg);
							-ms-transform: skew(-20deg);
									transform: skew(-20deg);
				}

				.block-head-5.magazine2 .tabs > .active:first-child a:before {
					width: 70%;
					right: 0;
					left: auto;
				}

				.block-head-5.magazine2 .tabs > .active:first-child a:after {
					content: "";
					position: absolute;
					z-index: -1;
					width: 50%;
					height: 100%;
					top: 0;
					left: 0;
					background-color: var(--brand-color);
				}

				.block-head-5.magazine2 .widget .tabs .active a {
					position: static;
				}

				.block-head-5.magazine2 .widget .tabs .active:last-child a:before {
					width: 70%;
					left: 0;
					right: auto;
				}

				.block-head-5.magazine2 .widget .tabs .active:last-child a:after {
					content: "";
					position: absolute;
					z-index: -1;
					width: 50%;
					height: 100%;
					top: 0;
					right: 0;
					left: auto;
					background-color: var(--brand-color);
				}
			';
			break;

		case '6':
			$out .= '
				.block-head-6 .has-block-head-4:after,
				.block-head-6 .mag-box-title h3:after,
				.block-head-6 .comment-reply-title:after,
				.block-head-6 .related.products > h2:after,
				.block-head-6 .up-sells > h2:after,
				.block-head-6 .cross-sells > h2:after,
				.block-head-6 .cart_totals > h2:after,
				.block-head-6 .bbp-form legend:after {
					content: "";
					position: absolute;
					right: 0;
					top: 0;
					width: 70%;
					height: 100%;
					background-color: var(--brand-color);
					-webkit-transform: skew(-40deg) translateX(14px);
							-ms-transform: skew(-40deg) translateX(14px);
									transform: skew(-40deg) translateX(14px);
					z-index: -1;
				}

				.block-head-6 .section-title-default {
					padding: 5px 25px;
				}

				.block-head-6 .section-title-default:after {
					-webkit-transform: skew(-40deg) translateX(32px);
							-ms-transform: skew(-40deg) translateX(32px);
									transform: skew(-40deg) translateX(32px);
				}

				.block-head-6#tie-body .widget-title:after {
					background: #111;
				}

				.block-head-6.magazine2 .tabs > .active a {
					background-color: transparent !important;
					position: relative;
				}

				.block-head-6.magazine2 .tabs > .active a:before {
					content: "";
					position: absolute;
					z-index: -1;
					width: 50%;
					height: 100%;
					top: 0;
					left: 0;
					background-color: var(--brand-color);
				}

				.block-head-6.magazine2 .tabs > .active a:after {
					content: "";
					position: absolute;
					z-index: -1;
					width: 70%;
					height: 100%;
					top: 0;
					right: 0;
					background-color: var(--brand-color);
					-webkit-transform: skew(-35deg);
							-ms-transform: skew(-35deg);
									transform: skew(-35deg);
				}

				.block-head-6.magazine2 .widget .tabs .active a {
					position: static;
				}

				.block-head-6.magazine2 .widget .tabs .active:last-child a:after {
					-webkit-transform: skew(0);
							-ms-transform: skew(0);
									transform: skew(0);
				}
			';
			break;

		case '7':
			$out .= '
				.block-head-7 .the-global-title,
				.block-head-7 .comment-reply-title,
				.block-head-7 .related.products > h2,
				.block-head-7 .up-sells > h2,
				.block-head-7 .cross-sells > h2,
				.block-head-7 .cart_totals > h2,
				.block-head-7 .bbp-form legend {
					position: relative;
					font-size: 15px;
					line-height: 1.3;
					font-weight: 500;
					margin-bottom: 20px;
					padding: 7px 10px;
					color: #ffffff;
					background-color: #111;
				}

				.block-head-7 .section-title-default {
					padding: 5px 15px;
				}

				.block-head-7 .mag-box-title h3 {
					font-size: 15px;
					line-height: 22px;
				}

				.block-head-7 .the-global-title a {
					color: #ffffff;
				}

				.block-head-7 .mag-box .mag-box-title .mag-box-filter-links a.active {
					color: var(--brand-color);
				}

				.block-head-7 .mag-box-title h3 a:hover,
				.block-head-7 .block-more-button:hover,
				.block-head-7 .section-title-default a:hover,
				.block-head-7 .widget-title a:hover {
					opacity: 0.8;
				}

				.block-head-7 .mag-box-filter-links .flexMenu-popup {
					top: 6px;
				}

				.block-head-7 .mag-box-filter-links .flexMenu-popup a:not(:hover):not(.active) {
					color: var(--base-color);
				}

				.dark-skin .block-head-7 .mag-box-filter-links .flexMenu-popup a:not(:hover):not(.active),
				.block-head-7 .dark-skin .mag-box-filter-links .flexMenu-popup a:not(:hover):not(.active) {
					color: #cccccc;
				}

				.block-head-7 .slider-arrow-nav {
					margin-right: -3px;
				}

				.block-head-7 .slider-arrow-nav a {
					border-color: rgba(255, 255, 255, 0.2);
				}

				.block-head-7 #footer .widget-title {
					display: inline-block;
				}

				.block-head-7 span.widget-title-icon {
					line-height: 19px;
				}

				.block-head-7 span.widget-title-icon {
					float: left;
					margin-right: 10px;
					line-height: 27px;
					position: static;
					color: #ffffff;
				}

				.block-head-7 .mag-box > .container-wrapper,
				.block-head-7 .widget-title,
				.block-head-7 #footer .widget,
				.block-head-7 .side-aside .widget {
					opacity: 0.99;
				}
			';
			break;

		case '8':
			$out .= '
				.block-head-8 .the-global-title,
				.block-head-8 .comment-reply-title,
				.block-head-8 .related.products > h2,
				.block-head-8 .up-sells > h2,
				.block-head-8 .cross-sells > h2,
				.block-head-8 .cart_totals > h2,
				.block-head-8 .bbp-form legend {
					position: relative;
					font-size: 15px;
					margin-bottom: 20px;
					padding-left: 20px;
					min-height: 0;
				}

				.dark-skin .block-head-8 .the-global-title, .dark-skin
				.block-head-8 .comment-reply-title, .dark-skin
				.block-head-8 .related.products > h2, .dark-skin
				.block-head-8 .up-sells > h2, .dark-skin
				.block-head-8 .cross-sells > h2, .dark-skin
				.block-head-8 .cart_totals > h2, .dark-skin
				.block-head-8 .bbp-form legend {
					color: #ffffff;
				}

				.block-head-8 .the-global-title:before,
				.block-head-8 .comment-reply-title:before,
				.block-head-8 .related.products > h2:before,
				.block-head-8 .up-sells > h2:before,
				.block-head-8 .cross-sells > h2:before,
				.block-head-8 .cart_totals > h2:before,
				.block-head-8 .bbp-form legend:before {
					content: "";
					background: var(--brand-color);
					height: 1em;
					width: 10px;
					position: absolute;
					top: 50%;
					-webkit-transform: translateY(-50%);
							-ms-transform: translateY(-50%);
									transform: translateY(-50%);
					left: 0;
				}

				.block-head-8 .section-title-default {
					padding-left: 25px;
				}

				.block-head-8 .section-title-default:before {
					height: 0.8em;
					width: 15px;
				}

				.block-head-8 .mag-box-title h3 {
					line-height: 22px;
				}

				.block-head-8 .dark-skin .the-global-title {
					color: #ffffff;
				}
			';
			break;

		case '9':
			$out .= '
				.block-head-9 .the-global-title,
				.block-head-9 .comment-reply-title,
				.block-head-9 .related.products > h2,
				.block-head-9 .up-sells > h2,
				.block-head-9 .cross-sells > h2,
				.block-head-9 .cart_totals > h2,
				.block-head-9 .bbp-form legend {
					margin-bottom: 25px;
				}

				.dark-skin .block-head-9 .the-global-title, .dark-skin
				.block-head-9 .comment-reply-title, .dark-skin
				.block-head-9 .related.products > h2, .dark-skin
				.block-head-9 .up-sells > h2, .dark-skin
				.block-head-9 .cross-sells > h2, .dark-skin
				.block-head-9 .cart_totals > h2, .dark-skin
				.block-head-9 .bbp-form legend {
					color: #ffffff;
				}

				.block-head-9 .widget-title .the-subtitle {
					text-align: center;
					-webkit-justify-content: center;
							-ms-flex-pack: center;
									justify-content: center;
					display: -webkit-flex;
					display: -ms-flexbox;
					display: flex;
					-webkit-flex-direction: row-reverse;
							-ms-flex-direction: row-reverse;
									flex-direction: row-reverse;
				}

				.block-head-9 .widget-title .the-subtitle .widget-title-icon {
					position: relative;
					padding-right: 5px;
					color: inherit;
				}

				.block-head-9 .mag-box-title h3 {
					line-height: 22px;
				}
			';
			break;

		case '10':
			$out .= '
				.block-head-10 .has-block-head-4,
				.block-head-10 .mag-box-title h3,
				.block-head-10 .comment-reply-title,
				.block-head-10 .related.products > h2,
				.block-head-10 .up-sells > h2,
				.block-head-10 .cross-sells > h2,
				.block-head-10 .cart_totals > h2,
				.block-head-10 .bbp-form legend {
					position: relative;
					opacity: 0.99;
					display: inline-block !important;
					width: auto;
					font-size: 15px;
					line-height: 1;
					font-weight: 500;
					margin-bottom: 20px;
				}

				.block-head-10 .has-block-head-4:after,
				.block-head-10 .mag-box-title h3:after,
				.block-head-10 .comment-reply-title:after,
				.block-head-10 .related.products > h2:after,
				.block-head-10 .up-sells > h2:after,
				.block-head-10 .cross-sells > h2:after,
				.block-head-10 .cart_totals > h2:after,
				.block-head-10 .bbp-form legend:after {
					content: "";
					position: absolute;
					right: 0;
					top: 0;
					width: 2px;
					height: 100%;
					z-index: -1;
					background-color: var(--brand-color);
					-webkit-transform: skew(-30deg) translateX(10px);
							-ms-transform: skew(-30deg) translateX(10px);
									transform: skew(-30deg) translateX(10px);
				}

				.block-head-10 .widget-title-icon {
					float: left;
					margin-right: 10px;
					position: static;
					color: inherit;
				}

				.block-head-10 .mag-box-title {
					position: relative;
					margin-bottom: 0;
				}

				.block-head-10 .mag-box-title h3 {
					font-size: 18px;
				}

				.block-head-10 .section-title-default {
					padding-right: 10px;
				}

				.block-head-10 #check-also-box .widget-title {
					padding-left: 30px;
				}

				.block-head-10 #check-also-close {
					left: 5px;
				}
			';
			break;

		case '11':
			$out .= '
				.block-head-11 .has-block-head-4,
				.block-head-11 .mag-box-title h3,
				.block-head-11 .comment-reply-title,
				.block-head-11 .related.products > h2,
				.block-head-11 .up-sells > h2,
				.block-head-11 .cross-sells > h2,
				.block-head-11 .cart_totals > h2,
				.block-head-11 .bbp-form legend {
					position: relative;
					opacity: 0.99;
					display: inline-block !important;
					width: auto;
					font-size: 15px;
					line-height: 1;
					font-weight: 500;
					margin-bottom: 20px;
					padding: 0;
					padding-right: 21px;
				}

				.block-head-11 .has-block-head-4:after,
				.block-head-11 .mag-box-title h3:after,
				.block-head-11 .comment-reply-title:after,
				.block-head-11 .related.products > h2:after,
				.block-head-11 .up-sells > h2:after,
				.block-head-11 .cross-sells > h2:after,
				.block-head-11 .cart_totals > h2:after,
				.block-head-11 .bbp-form legend:after {
					content: "";
					position: absolute;
					right: 0;
					top: 0;
					width: 0;
					height: 0;
					z-index: -1;
					opacity: .5;
					border-color: transparent transparent transparent var(--brand-color);
					border-style: solid;
					border-width: 16px 0 0 13px;
				}

				.block-head-11 .widget-title-icon {
					float: left;
					margin-right: 10px;
					position: static;
					color: inherit;
				}

				.block-head-11 .mag-box-title {
					position: relative;
					margin-bottom: 0;
				}

				.block-head-11 .mag-box-title h3 {
					font-size: 18px;
				}

				.block-head-11 .section-title-default {
					padding-right: 50px;
				}

				.block-head-11 .section-title-default:after {
					border-width: 45px 0 0 40px;
				}

				.block-head-11 #check-also-box .widget-title {
					padding-left: 30px;
				}

				.block-head-11 #check-also-close {
					left: 5px;
				}

				.block-head-11 #footer.dark-skin .the-global-title::after {
					background: transparent !important;
				}
			';
			break;
	}

	$out = apply_filters( 'TieLabs/inline_styles/blocks_head', $out, $block_style );

	if( ! empty( $out ) ) {
		TIELABS_STYLES::print_inline_css( $out );
	}
}