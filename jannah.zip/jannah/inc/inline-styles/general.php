<?php
/**
 * General Inline Styles
 *
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly

/**
 * Inline general Styles
 */
function tie_get_inline_general_styles( $id = false ){

	$out = '';

	switch( $id ){

		case 'weather':
			$out = '
				.tie-weather-widget.widget {
					background: var(--brand-color);
					color: var(--bright-color);
					border-width: 0;
					padding: 0;
					position: relative;
					overflow: hidden;
				}

				.tie-weather-widget.widget .icon-basecloud-bg:after {
					color: var(--brand-color);
				}

				.tie-weather-widget.widget .user-weather-error {
					position: absolute;
					width: 100%;
					top: 0;
				}

				.tie-weather-widget.widget .user-weather-error .theme-notice {
					background: rgba(255, 0, 0, 0.5);
					color: #fff !important;
					text-align: center;
					padding: 0;
				}

				.tie-weather-widget .widget-title {
					border-bottom: 0 !important;
					background-color: transparent;
					margin-bottom: 0;
					padding: 20px 20px 0;
				}

				.tie-weather-widget .widget-title:after, .tie-weather-widget .widget-title:before {
					display: none;
				}

				.tie-weather-widget .widget-title .the-subtitle {
					font-size: 18px;
					color: var(--bright-color);
					margin: 0;
					padding: 0;
				}

				.tie-weather-widget .widget-title .the-subtitle:after, .tie-weather-widget .widget-title .the-subtitle:before,
				.tie-weather-widget .widget-title .the-subtitle .widget-title-icon {
					display: none;
				}

				.tie-weather-widget .widget-title span {
					font-weight: normal;
					font-size: 14px;
				}

				.tie-weather-widget [class^="icon-"]:before, .tie-weather-widget [class^="icon-"]:after,
				.tie-weather-widget [class*=" icon-"]:before,
				.tie-weather-widget [class*=" icon-"]:after {
					font-family: "tiefonticon";
				}

				.tie-weather-user-location {
					position: absolute;
					font-size: 22px;
					display: block;
					top: 10px;
					right: 10px;
				}

				.tie-weather-user-location.has-title {
					top: 20px;
					right: 20px;
				}

				.tie-weather-user-location:not(.is-loading) {
					cursor: pointer;
				}

				.tie-weather-user-location .tie-icon-gps:not(:hover) {
					opacity: 0.5;
				}

				.tie-weather-user-location .tie-icon-spinner {
					-webkit-animation: tie-spin 1s infinite linear;
									animation: tie-spin 1s infinite linear;
					opacity: 0.5;
				}

				.weather-name {
					font-size: 32px;
					padding-top: 5px;
					font-weight: bold;
					white-space: nowrap;
				}

				.weather-todays-stats {
					display: inline-block;
					padding: 0 10px;
					vertical-align: top;
				}

				.weather-more-todays-stats {
					text-align: left;
					line-height: 1.6;
					font-size: 90%;
					padding-top: 12px;
					padding-left: 10px;
				}

				.weather-more-todays-stats [class^="tie-icon-"]:before,
				.weather-more-todays-stats [class*=" tie-icon-"]:before {
					width: 15px;
					display: inline-block;
					text-align: center;
				}

				.weather-desc {
					margin-top: 5px;
				}

				.weather-forecast {
					clear: both;
					padding: 20px 10px;
					overflow: hidden;
					margin: 20px 0 -20px;
				}

				.weather-forecast-day {
					position: relative;
					width: 1%;
					display: table-cell;
					text-align: center;
				}

				.weather-forecast-day .weather-icon {
					font-size: 35px;
				}

				.weather-forecast-day .weather-icon .icon-cloud:after,
				.weather-forecast-day .weather-icon .icon-basecloud-bg:after,
				.weather-forecast-day .weather-icon .basecloud:before {
					font-size: inherit;
					line-height: 1.05;
				}

				.weather-forecast-day .weather-icon .icon-rainy-animi-5,
				.weather-forecast-day .weather-icon .icon-thunder-animi:after,
				.weather-forecast-day .weather-icon .icon-windysnow-animi-2 {
					display: none;
				}

				.weather-forecast-day-abbr {
					font-weight: bold;
					font-size: 0.8em;
					margin-top: 3px;
					line-height: 1.4;
				}

				.weather-forecast-day-temp {
					font-size: 14px;
				}

				.weather-forecast-day-temp sup {
					font-size: 8px;
					padding-left: 2px;
				}
			';
			break;
	}

	return apply_filters( 'TieLabs/inline_styles/general', $out, $id );
}