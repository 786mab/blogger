<?php
/**
 * Widgets Inline Styles
 *
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly

/**
 * Inline Widgets Styles
 */
function tie_get_inline_widgets_styles( $id = false ){

	$out = '';

	switch( $id ){

		case 'facebook-widget':
			$out = '
				.facebook-widget .widget-title-icon:before {
					content: "\f09a";
				}

				.facebook-widget .fb_iframe_widget{
					margin: 0 auto;
					max-width: 100%;
					display: table !important;
				}
			';
			break;

		case 'tie-soundcloud-widget':
			$out = '
				.soundcloud-widget .widget-title-icon:before {
					content: "\f1be";
				}
			';
			break;

		case 'youtube-widget':
			$out = '
				.widget_youtube-widget .widget-title-icon:before {
					content: "\f16a";
				}
			
				.widget_youtube-widget .youtube-box{
					text-align: center;
				}
			';
			break;

		case 'tie-newsletter':
			$out = '
				.subscribe-widget .widget-inner-wrap {
					text-align: center;
				}
				
				.subscribe-widget .widget-title {
					text-align: left;
				}
				
				.subscribe-widget .widget-title-icon:before {
					content: "\f0e0";
				}
				
				.subscribe-widget .newsletter-icon {
					color: rgba(0, 0, 0, 0.2);
					font-size: 40px;
					display: block;
					margin: 0 0 20px;
					line-height: 0.8;
				}
				
				.subscribe-widget .subscribe-widget-content {
					margin-bottom: 20px;
				}
				
				.subscribe-widget .subscribe-widget-content h4 {
					font-size: 15px;
					position: relative;
					padding-bottom: 10px;
					margin-bottom: 10px;
				}
				
				.subscribe-widget .subscribe-widget-content h4:after {
					content: "";
					position: absolute;
					width: 50px;
					height: 1px;
					background-color: rgba(0, 0, 0, 0.1);
					bottom: 0;
					left: 50%;
					right: auto;
					-webkit-transform: translateX(-50%);
							-ms-transform: translateX(-50%);
									transform: translateX(-50%);
					transition: 0.15s;
				}
				
				.subscribe-widget .subscribe-widget-content h3 {
					font-size: 28px;
					color: #2c2f34;
					margin-bottom: 10px;
				}
				
				.subscribe-widget form {
					position: relative;
				}
				
				.subscribe-widget form:before {
					font-size: 15px;
					position: absolute;
					left: 12px;
					top: 10px;
					color: rgba(0, 0, 0, 0.2);
					font-size: 18px;
					content: "\f0e0";
					font-family: tiefonticon;
				}
				
				.subscribe-widget .subscribe-input {
					padding: 8px 30px;
					width: 100%;
					text-align: center;
					font-size: 13px;
				}
				
				.subscribe-widget .subscribe-input::-webkit-input-placeholder {
					text-align: center;
				}
				
				.subscribe-widget .subscribe-input::-moz-placeholder {
					text-align: center;
				}
				
				.subscribe-widget .subscribe-input:-moz-placeholder {
					text-align: center;
				}
				
				.subscribe-widget .subscribe-input:-ms-input-placeholder {
					text-align: center;
				}
				
				.subscribe-widget .button {
					margin-top: 10px;
					padding: 10px !important;
					width: 100%;
					font-size: 14px;
				}
			';
			break;

		case 'tie-snapchat-theme':
			$out = '
				.widget_tie-snapchat-theme .widget-title-icon::before {
					content: "\f2ac";
				}
				.tie-snapchat-badge{
					display: block;
					background-repeat: no-repeat;
					background-position: center;
					font-size: 0;
					line-height: 0;
					border: 3px solid #000;
					overflow: hidden;
					width: 200px;
					margin: 0 auto;
					border-radius: 20px;
					transition: all 0.25s;
				}
				.tie-snapchat-badge.is-circle{
					border-radius: 100%;
				}
				.tie-snapchat-badge-wrap a:hover{
					color: #e6e419;
				}
				.tie-snapchat-badge-wrap .snapchat-username,
				.tie-snapchat-badge-wrap .snapchat-userid{
					text-align: center;
					display: block;
				}
				.tie-snapchat-badge-wrap .snapchat-username{
					margin-top: 10px;
					font-size: 20px;
					font-weight: bold;
				}
			';
			break;

		case 'flickr_photos-widget':
			$out = '
				.flickr-widget .widget-title-icon:before {
					content: "\f16e";
				}
				.flickr-widget .flickr_badge_image {
					width: 33.33333%;
					padding: 0 2px 4px;
					position: relative;
					min-height: 1px;
					float: left;
					line-height: 0;
				}
				.flickr-widget .flickr-images-wrapper {
					margin: 0 -2px;
				}
				.flickr-widget a {
					display: block;
				}
				.flickr-widget img {
					width: 100%;
					transition: 0.3s;
				}
				.flickr-widget img:hover {
					opacity: 0.8;
				}
				.flickr-widget a.button {
					margin-top: 10px;
				}
			';
			break;

		case 'latest_tweets_widget':
			$out = '
				.latest-tweets-widget {
					position: relative;
					min-height: 80px;
				}

				.latest-tweets-widget .widget-title-icon:before {
					content: "\f099";
				}

				.latest-tweets-widget li {
					padding: 0 0 10px;
				}

				.latest-tweets-widget li:last-child {
					padding: 0;
					margin-bottom: 0;
					border-bottom: 0;
				}

				.latest-tweets-widget .widget-title + ul {
					margin-bottom: 20px;
				}

				.twitter-icon-wrap {
					width: 20px;
					float: left;
				}

				.twitter-icon-wrap span {
					color: var(--brand-color);
					margin-top: 5px;
				}

				.latest-tweets-widget .tweetaya-body {
					padding-left: 20px;
				}

				.latest-tweets-widget .tweetaya-meta {
					display: block;
					font-size: 11px;
					text-align: right;
				}

				.latest-tweets-widget .tie-slick-slider {
					display: none;
					position: relative;
					border-radius: 2px;
				}

				.latest-tweets-widget .tie-slick-slider .slick-list {
					width: 100%;
				}

				.latest-tweets-widget .tie-slick-slider li {
					border: 0;
					height: 58px;
					padding-bottom: 0;
					overflow: hidden;
				}

				.latest-tweets-widget .tie-slick-slider .twitter-icon-wrap {
					width: 40px;
					height: 40px;
					line-height: 40px;
					background: #40bff5;
					border-radius: 2px;
					margin-right: 20px;
					text-align: center;
					display: none;
				}

				.latest-tweets-widget .tie-slick-slider .tweetaya-body {
					padding: 0;
				}

				.latest-tweets-widget .tie-slick-slider .tweetaya-body p {
					margin: 0;
				}

				.latest-tweets-widget .slider-links {
					float: right;
					display: none;
				}

				.latest-tweets-widget .slider-links .button {
					line-height: 23px;
					padding: 1px 10px;
					margin-right: 10px;
				}

				.latest-tweets-widget .slider-links .tie-slider-nav {
					margin: 0;
					opacity: 1;
					float: right;
					position: static;
					width: auto;
				}

				.latest-tweets-widget .slider-links .tie-slider-nav li {
					padding: 0;
					border: 0;
					margin-bottom: 0;
					margin-left: 5px;
					float: right;
				}

				.latest-tweets-widget .slider-links .tie-slider-nav li span {
					width: 25px;
					height: 25px;
					border: 1px solid rgba(0, 0, 0, 0.1);
					line-height: 23px;
					position: relative;
					top: 0;
					cursor: pointer;
					font-size: 14px;
				}

				.dark-skin .latest-tweets-widget .slider-links .tie-slider-nav li span:not(:hover) {
					background-color: transparent;
				}

				.latest-tweets-widget .slick-initialized ~ .slider-links {
					display: block;
				}

				.normal-side .latest-tweets-widget .tie-slick-slider .tweetaya-body p {
					white-space: normal;
					display: block;
					display: -webkit-box;
					height: 36.4px;
					margin: 0 auto;
					font-size: 13px;
					line-height: 1.4;
					-webkit-line-clamp: 2;
					-webkit-box-orient: vertical;
					overflow: hidden;
					text-overflow: ellipsis;
				}

				.fullwidth-area .latest-tweets-widget {
					padding-bottom: 0;
				}

				@media (max-width: 767px) {
					.fullwidth-area .latest-tweets-widget {
						max-height: inherit;
					}
				}

				.fullwidth-area .latest-tweets-widget .tie-slick-slider {
					margin-bottom: 0;
					background: rgba(0, 0, 0, 0.15);
					padding: 20px;
				}

				.fullwidth-area .latest-tweets-widget .tie-slick-slider .slide {
					margin: 2px 0;
					height: auto;
				}

				.fullwidth-area .latest-tweets-widget .tie-slick-slider .twitter-icon-wrap {
					display: inline-block;
				}

				.fullwidth-area .latest-tweets-widget .tie-slick-slider .twitter-icon-wrap span {
					color: #ffffff !important;
				}

				.fullwidth-area .latest-tweets-widget .tie-slick-slider .tweetaya-body {
					width: calc(100% - 160px);
					padding-left: 60px;
				}

				.fullwidth-area .latest-tweets-widget .tie-slick-slider .tweetaya-body p {
					display: block;
					overflow: hidden;
					white-space: nowrap;
					word-wrap: normal;
					text-overflow: ellipsis;
				}

				.fullwidth-area .latest-tweets-widget .tie-slick-slider .tweetaya-body .tweetaya-meta {
					display: inline;
				}

				@media (max-width: 767px) {
					.fullwidth-area .latest-tweets-widget .tie-slick-slider .slide {
						height: 58px;
					}
					.fullwidth-area .latest-tweets-widget .tie-slick-slider .tweetaya-body p {
						white-space: normal;
						display: block;
						display: -webkit-box;
						height: 36.4px;
						margin: 0 auto;
						font-size: 13px;
						line-height: 1.4;
						-webkit-line-clamp: 2;
						-webkit-box-orient: vertical;
						overflow: hidden;
						text-overflow: ellipsis;
					}
				}

				.fullwidth-area .latest-tweets-widget ul:not(.tie-slick-slider) .tweetaya-meta {
					text-align: left;
				}

				.fullwidth-area .latest-tweets-widget .slider-links {
					margin: 0;
					right: 20px;
					top: 40px;
					bottom: 35px;
					position: absolute;
				}

				@media (min-width: 601px) {
					.fullwidth-area .latest-tweets-widget .widget-title ~ .slider-links {
						top: 100px;
					}
				}

				@media (max-width: 600px) {
					.fullwidth-area .latest-tweets-widget .tie-slick-slider {
						padding-bottom: 60px;
					}
					.fullwidth-area .latest-tweets-widget .tie-slick-slider .tweetaya-body {
						width: 100%;
					}
					.fullwidth-area .latest-tweets-widget .slider-links {
						top: auto;
						bottom: 35px;
					}
				}

				@media (max-width: 479px) {
					.fullwidth-area .latest-tweets-widget .tie-slick-slider .tweetaya-body {
						padding-left: 0;
					}
					.fullwidth-area .latest-tweets-widget .tie-slick-slider .twitter-icon-wrap {
						display: none;
					}
				}
			';
			break;

		case 'social-statistics':
			$out = '
				.social-statistics-widget .widget-title-icon:before {
					content: "\f164";
				}

				.social-statistics-widget ul {
					overflow: hidden;
				}

				.social-statistics-widget li {
					float: left;
					width: 50%;
					margin-left: 0;
					padding: 10px 5px 0;
					border-bottom: 0;
				}

				.social-statistics-widget li:last-child {
					margin-bottom: 0;
				}

				.social-statistics-widget .followers-num {
					font-weight: 600;
				}

				.social-statistics-widget .followers-name {
					font-size: 11px;
				}

				.social-statistics-widget a {
					display: block;
					padding: 10px;
					position: relative;
					overflow: hidden;
					border-radius: 2px;
				}

				.social-statistics-widget a:hover {
					opacity: 0.8;
				}

				.social-statistics-widget a span.counter-icon {
					float: left;
					color: #ffffff;
					background-color: #2c2f34;
					width: 30px;
					height: 30px;
					line-height: 30px;
					text-align: center;
					font-size: 18px;
					border-radius: 2px;
					transition: 0.3s;
				}

				.social-statistics-widget .followers {
					float: left;
					margin-left: 10px;
					line-height: 15px;
				}

				.social-statistics-widget .followers .followers-num,
				.social-statistics-widget .followers .followers-name {
					color: #ffffff;
					display: block;
					transition: 0.3s;
					white-space: nowrap;
					word-wrap: normal;
				}

				.social-statistics-widget .followers .followers-name {
					opacity: 0.8;
				}

				.social-counter-total {
					margin-bottom: 15px;
					font-size: 120%;
					text-align: center;
				}

				ul + .social-counter-total {
					margin-bottom: 0;
					margin-top: 15px;
				}

				.social-counter-total .tie-icon-heart {
					color: red;
				}

				.two-cols {
					margin-left: -5px;
					margin-right: -5px;
				}

				.two-cols:not(.fullwidth-stats-icons) li:nth-child(2) {
					padding-top: 0;
				}

				.two-cols li:nth-last-child(-n + 2) {
					margin-bottom: 0;
				}

				.two-cols li:nth-child(2n + 1) {
					clear: both;
				}

				@media (min-width: 1050px) {
					.two-cols li:nth-child(odd):last-child {
						width: 100%;
					}
				}

				.two-cols:not(.transparent-icons):not(.white-bg) a span.counter-icon,
				.fullwidth-stats-icons:not(.transparent-icons):not(.white-bg) a span.counter-icon {
					background: #2c2f34 !important;
				}

				.fullwidth-stats-icons li {
					width: 100%;
					margin-left: 0;
					margin-right: 0;
					padding: 10px 0 0;
					position: relative;
				}

				.fullwidth-stats-icons li:before {
					content: "";
					position: absolute;
					z-index: 1;
					width: 1px;
					height: calc(100% - 10px);
					left: 50px;
					top: 10px;
					background: rgba(255, 255, 255, 0.3);
				}

				.fullwidth-stats-icons li:first-child {
					padding-top: 0;
				}

				.fullwidth-stats-icons li:first-child:before {
					height: 100%;
					top: 0;
				}

				.fullwidth-stats-icons .followers {
					margin-left: 30px;
				}

				.fullwidth-stats-icons .followers span {
					float: left;
					line-height: 30px;
					margin-right: 5px;
				}

				.transparent-icons li a span.counter-icon {
					background-color: transparent;
				}

				.white-bg .social-icons-item:before {
					background: rgba(0, 0, 0, 0.1);
				}

				.white-bg .social-icons-item a {
					border: 1px solid rgba(0, 0, 0, 0.1) !important;
					background: transparent !important;
				}

				.white-bg .social-icons-item a span.followers span {
					color: var(--base-color);
				}

				.dark-skin .white-bg .social-icons-item a span.followers span {
					color: #cccccc;
				}

				.circle-icons .social-icons-item a span.counter-icon {
					border-radius: 50%;
					width: 35px;
					height: 35px;
					line-height: 35px;
				}

				.circle-icons.two-cols .social-icons-item a {
					border: 0 !important;
				}

				.three-cols:not(.three-cols-without-spaces) {
					margin-right: -5px;
					margin-left: -5px;
				}

				.three-cols .social-icons-item {
					width: 33.3333%;
					margin: 0;
					overflow: hidden;
				}

				.three-cols .social-icons-item:nth-child(-n + 3) {
					padding-top: 0;
				}

				.three-cols .social-icons-item:nth-child(3n + 1) {
					clear: both;
				}

				.three-cols .social-icons-item:nth-last-child(-n + 3) {
					margin-bottom: 0;
				}

				.three-cols .social-icons-item a {
					padding: 0;
				}

				.three-cols .social-icons-item a span.counter-icon {
					line-height: 60px;
					height: 60px;
					font-size: 25px;
					width: 100%;
					text-align: center;
					background-color: transparent;
					color: #ffffff;
				}

				.three-cols .social-icons-item .followers {
					background: rgba(255, 255, 255, 0.2);
					margin: 0;
					width: 100%;
					min-height: 58px;
					padding: 10px 0;
					text-align: center;
					line-height: 19px;
				}

				.three-cols-without-spaces .social-icons-item:nth-child(n) {
					padding: 0;
				}

				.three-cols-without-spaces .social-icons-item:nth-child(n) a {
					border-radius: 0;
				}

				.three-cols-without-spaces .social-icons-item:nth-child(n) a span.counter-icon {
					padding-top: 5px;
				}

				.three-cols-without-spaces .social-icons-item:nth-child(n) .followers {
					background-color: transparent;
					padding-top: 0;
				}

				.three-cols-without-spaces .social-icons-item:nth-child(n) .followers-num {
					font-size: 18px;
				}

				.circle-three-cols {
					margin-right: -10px;
					margin-left: -10px;
				}

				.circle-three-cols .social-icons-item {
					width: calc(100% / 3);
					margin-right: 0;
					height: 125px;
					overflow: hidden;
					padding: 0;
				}

				.circle-three-cols .social-icons-item:before {
					background: rgba(0, 0, 0, 0.1);
				}

				.circle-three-cols .social-icons-item a {
					position: relative;
					background: transparent !important;
				}

				.circle-three-cols .social-icons-item a .followers-num,
				.circle-three-cols .social-icons-item a .followers-name {
					color: var(--base-color);
				}

				.dark-skin .circle-three-cols .social-icons-item a .followers-num, .dark-skin
				.circle-three-cols .social-icons-item a .followers-name {
					color: #cccccc;
				}

				.circle-three-cols .social-icons-item a span {
					position: relative;
					z-index: 2;
				}

				.circle-three-cols .social-icons-item a span.counter-icon {
					color: #ffffff !important;
					width: 70px;
					height: 70px;
					line-height: 70px;
					font-size: 25px;
					position: relative;
					left: 50%;
					margin-left: -35px;
				}

				.circle-three-cols .social-icons-item .followers {
					margin: 10px 0 0 0;
					width: 100%;
					text-align: center;
				}

				.circle-three-cols .social-icons-item .followers-num {
					font-size: 15px;
				}

				.squared-four-cols {
					margin-right: -10px;
					margin-left: -10px;
				}

				.squared-four-cols li {
					width: 25%;
					margin: 0;
				}

				.squared-four-cols li:nth-child(-n + 4) {
					padding-top: 0;
				}

				.squared-four-cols li:nth-child(4n + 1) {
					clear: both;
				}

				.squared-four-cols li:nth-child(n) a {
					border: 0 !important;
					padding-top: 0;
				}

				.squared-four-cols li:nth-child(n) a .counter-icon {
					position: relative;
					left: 50%;
					width: 54px;
					height: 54px;
					line-height: 54px;
					margin-left: -27px;
					font-size: 20px;
				}

				.squared-four-cols li:nth-child(n) .followers {
					text-align: center;
					margin: 10px 0 0;
					display: block;
					width: 100%;
				}

				@media only screen and (min-width: 992px) and (max-width: 1050px) {
					.two-cols.white-bg:not(.circle-icons) li,
					.two-cols.transparent-icons li,
					.two-cols:not(.transparent-icons):not(.white-bg) li {
						width: 100%;
					}
					.two-cols.white-bg:not(.circle-icons) li:nth-child(2),
					.two-cols.transparent-icons li:nth-child(2),
					.two-cols:not(.transparent-icons):not(.white-bg) li:nth-child(2) {
						padding-top: 10px;
					}
					.two-cols.white-bg.circle-icons li a {
						padding: 10px 0;
					}
					.squared-four-cols li {
						width: 33.3334%;
					}
					.squared-four-cols li:nth-child(4n + 1) {
						clear: none;
					}
					.squared-four-cols li:nth-child(3n + 1) {
						clear: both;
					}
				}

				@media only screen and (min-width: 768px) and (max-width: 991px) {
					.two-cols.white-bg,
					.two-cols.transparent-icons,
					.two-cols:not(.transparent-icons):not(.white-bg),
					.fullwidth-stats-icons {
						margin-left: -5px;
						margin-right: -5px;
					}
					.two-cols.white-bg li,
					.two-cols.transparent-icons li,
					.two-cols:not(.transparent-icons):not(.white-bg) li,
					.fullwidth-stats-icons li {
						width: 25%;
						padding-left: 5px;
						padding-right: 5px;
					}
					.two-cols.white-bg li:before,
					.two-cols.transparent-icons li:before,
					.two-cols:not(.transparent-icons):not(.white-bg) li:before,
					.fullwidth-stats-icons li:before {
						left: 55px;
					}
					.two-cols.white-bg li:nth-child(-n + 4),
					.two-cols.transparent-icons li:nth-child(-n + 4),
					.two-cols:not(.transparent-icons):not(.white-bg) li:nth-child(-n + 4),
					.fullwidth-stats-icons li:nth-child(-n + 4) {
						padding-top: 0;
					}
					.two-cols.white-bg li:nth-child(-n + 4):before,
					.two-cols.transparent-icons li:nth-child(-n + 4):before,
					.two-cols:not(.transparent-icons):not(.white-bg) li:nth-child(-n + 4):before,
					.fullwidth-stats-icons li:nth-child(-n + 4):before {
						top: 0;
						height: 100%;
					}
					.two-cols.white-bg li:nth-child(2n + 1),
					.two-cols.transparent-icons li:nth-child(2n + 1),
					.two-cols:not(.transparent-icons):not(.white-bg) li:nth-child(2n + 1),
					.fullwidth-stats-icons li:nth-child(2n + 1) {
						clear: none;
					}
					.two-cols.white-bg li:nth-child(4n + 1),
					.two-cols.transparent-icons li:nth-child(4n + 1),
					.two-cols:not(.transparent-icons):not(.white-bg) li:nth-child(4n + 1),
					.fullwidth-stats-icons li:nth-child(4n + 1) {
						clear: both;
					}
					.two-cols.white-bg li .followers span,
					.two-cols.transparent-icons li .followers span,
					.two-cols:not(.transparent-icons):not(.white-bg) li .followers span,
					.fullwidth-stats-icons li .followers span {
						float: none;
						line-height: inherit;
					}
					.three-cols .social-icons-item,
					.white-bg.two-cols .social-icons-item,
					.circle-three-cols .social-icons-item,
					.squared-four-cols .social-icons-item {
						width: 20%;
					}
					.three-cols .social-icons-item:nth-child(-n + 5),
					.white-bg.two-cols .social-icons-item:nth-child(-n + 5),
					.circle-three-cols .social-icons-item:nth-child(-n + 5),
					.squared-four-cols .social-icons-item:nth-child(-n + 5) {
						padding-top: 0;
					}
					.three-cols .social-icons-item:nth-child(5n + 1),
					.white-bg.two-cols .social-icons-item:nth-child(5n + 1),
					.circle-three-cols .social-icons-item:nth-child(5n + 1),
					.squared-four-cols .social-icons-item:nth-child(5n + 1) {
						clear: both;
					}
					.three-cols .social-icons-item:nth-child(3n + 1), .three-cols .social-icons-item:nth-child(4n + 1),
					.white-bg.two-cols .social-icons-item:nth-child(3n + 1),
					.white-bg.two-cols .social-icons-item:nth-child(4n + 1),
					.circle-three-cols .social-icons-item:nth-child(3n + 1),
					.circle-three-cols .social-icons-item:nth-child(4n + 1),
					.squared-four-cols .social-icons-item:nth-child(3n + 1),
					.squared-four-cols .social-icons-item:nth-child(4n + 1) {
						clear: none;
					}
				}

				.dark-skin .social-statistics-widget .white-bg li.social-icons-item:before {
					background: rgba(255, 255, 255, 0.1);
				}

				.dark-skin .social-statistics-widget .white-bg li.social-icons-item a {
					border-color: rgba(255, 255, 255, 0.1) !important;
				}

				.dark-skin .social-statistics-widget .white-bg li.social-icons-item a:after {
					background: rgba(255, 255, 255, 0.1);
				}

				.social-icons-item .arqicon-goodreads {
					line-height: 2.5 !important;
				}

				.social-icons-item .arqicon-goodreads svg {
					width: 20px;
					height: 20px;
				}

				.social-statistics-widget ul.three-cols .arqicon-goodreads,
				.social-statistics-widget ul.circle-three-cols .arqicon-goodreads,
				.social-statistics-widget ul.squared-four-cols .arqicon-goodreads {
					line-height: 3 !important;
				}

				.social-statistics-widget ul.three-cols .arqicon-goodreads svg,
				.social-statistics-widget ul.circle-three-cols .arqicon-goodreads svg,
				.social-statistics-widget ul.squared-four-cols .arqicon-goodreads svg {
					width: 25px;
					height: 25px;
				}

				.social-statistics-widget ul.circle-three-cols .arqicon-goodreads {
					line-height: 3.7 !important;
				}

				.social-statistics-widget svg path {
					fill: #FFF;
				}

				@supports (-ms-accelerator: true) {
					.social-statistics-widget a {
						transition: none;
					}
				}

				.social-icons-item .mailchimp-social-icon,
				.social-icons-item .mailchimp-social-icon .counter-icon,
				.social-icons-item .mailpoet-social-icon,
				.social-icons-item .mailpoet-social-icon .counter-icon,
				.social-icons-item .mymail-social-icon,
				.social-icons-item .mymail-social-icon .counter-icon {
					background-color: #2c9ab7;
				}

				.social-icons-item .posts-social-icon,
				.social-icons-item .posts-social-icon .counter-icon {
					background-color: #9b59b6;
				}

				.social-icons-item .comments-social-icon,
				.social-icons-item .comments-social-icon .counter-icon {
					background-color: #1abc9c;
				}

				.social-icons-item .groups-social-icon,
				.social-icons-item .groups-social-icon .counter-icon {
					background-color: #788cb6;
				}

				.social-icons-item .forums-social-icon,
				.social-icons-item .forums-social-icon .counter-icon {
					background-color: #88aca1;
				}

				.social-icons-item .members-social-icon,
				.social-icons-item .members-social-icon .counter-icon {
					background-color: #dc5034;
				}

				.social-icons-item .topics-social-icon,
				.social-icons-item .topics-social-icon .counter-icon {
					background-color: #613854;
				}

				.social-icons-item .replies-social-icon,
				.social-icons-item .replies-social-icon .counter-icon {
					background-color: #71c6c1;
				}


				.social-icons-item .facebook-social-icon span.counter-icon {
					background-color: #4080FF;
				}

				.social-icons-item .twitter-social-icon span.counter-icon {
					background-color: #40bff5;
				}

				.social-icons-item .pinterest-social-icon span.counter-icon {
					background-color: #e13138;
				}

				.social-icons-item .linkedin-social-icon span.counter-icon {
					background-color: #238cc8;
				}

				.social-icons-item .instagram-social-icon span.counter-icon {
					background-color: #c13584;
				}

				.social-icons-item .vimeo-social-icon span.counter-icon {
					background-color: #35c6ea;
				}

				.social-icons-item .dribbble-social-icon span.counter-icon {
					background-color: #f7659c;
				}

				.social-icons-item .youtube-social-icon span.counter-icon {
					background-color: #ef4e41;
				}

				.social-icons-item .soundcloud-social-icon span.counter-icon {
					background-color: #ff7e30;
				}

				.social-icons-item .flickr-social-icon span.counter-icon {
					background-color: #ff48a3;
				}

				.social-icons-item .github-social-icon span.counter-icon {
					background-color: #3f91cb;
				}

				.social-icons-item .behance-social-icon span.counter-icon {
					background-color: #1879fd;
				}

				.social-icons-item .foursquare-social-icon span.counter-icon {
					background-color: #f94877;
				}

				.social-icons-item .px500-social-icon span.counter-icon {
					background-color: #0099e5;
				}

				.social-icons-item .vk-social-icon span.counter-icon {
					background-color: #45668e;
				}

				.social-icons-item .mixcloud-social-icon span.counter-icon {
					background-color: #589fC3;
				}

				.social-icons-item .twitch-social-icon span.counter-icon {
					background-color: #6441a5;
				}

				.social-icons-item .rss-social-icon span.counter-icon {
					background-color: #faa33d;
				}

				.social-icons-item .goodreads-social-icon span.counter-icon {
					background-color: #A06E0A;
				}

				.social-icons-item .steam-social-icon span.counter-icon {
					background-color: #111111;
				}
			';
			break;

		case 'posts-list-widget':

			$out = '
				.widget-posts-list-container {
					position: relative;
				}

				.widget-posts-list-container.is-loading {
					opacity: 0.5;
					transition: opacity 0.3s;
				}

				.widget-pagination-wrapper {
					clear: both;
					overflow: hidden;
					margin-top: 15px !important;
				}

				.widget-pagination-wrapper .slider-arrow-nav {
					display: -webkit-flex;
					display: -ms-flexbox;
					display: flex;
					float: none;
					margin: 0;
					-webkit-justify-content: center;
							-ms-flex-pack: center;
									justify-content: center;
				}

				.widget-pagination-wrapper .slider-arrow-nav li {
					margin: 0;
					padding: 0;
				}

				.widget-pagination-wrapper .slider-arrow-nav a {
					width: 30px;
					height: 30px;
					line-height: 28px;
				}

				.widget-pagination-wrapper .widget-pagination {
					margin-top: 0 !important;
				}
			';
			break;

		case 'posts-list-widget-7':

			$out = '
				.posts-list-counter {
					counter-reset: post-widget-counter;
				}

				.posts-list-counter li.widget-post-list:before {
					display: block;
					width: 30px;
					height: 30px;
					content: counter(post-widget-counter, decimal);
					counter-increment: post-widget-counter;
					position: absolute;
					z-index: 2;
					top: 0;
					left: -15px;
					text-align: center;
					font-size: 14px;
					font-weight: 600;
					line-height: 26px;
					border: 2px solid #ffffff;
					background: var(--brand-color);
					color: var(--bright-color);
					border-radius: 100%;
				}

				@media (max-width: 991px) {
					.magazine2 .posts-list-counter li.widget-post-list:before {
						left: -10px;
					}
				}

				.dark-skin .posts-list-counter li.widget-post-list:before {
					border-color: #27292d;
				}

				.site-footer .posts-list-counter li.widget-post-list:before,
				.side-aside.dark-skin .posts-list-counter li.widget-post-list:before {
					border-color: #1f2024;
				}

				.posts-list-counter li.widget-post-list:nth-child(1):before {
					top: -10px;
					-webkit-transform: scale(1.35, 1.35);
							-ms-transform: scale(1.35, 1.35);
									transform: scale(1.35, 1.35);
				}

				.posts-list-counter li.widget-post-list:nth-child(2):before {
					-webkit-transform: scale(1.25, 1.25);
							-ms-transform: scale(1.25, 1.25);
									transform: scale(1.25, 1.25);
				}

				.posts-list-counter li.widget-post-list:nth-child(3):before {
					-webkit-transform: scale(1.15, 1.15);
							-ms-transform: scale(1.15, 1.15);
									transform: scale(1.15, 1.15);
				}

				.posts-list-counter li.widget-post-list:nth-child(4):before {
					-webkit-transform: scale(1.1, 1.1);
							-ms-transform: scale(1.1, 1.1);
									transform: scale(1.1, 1.1);
				}

				.posts-list-counter li.widget-post-list .no-small-thumbs {
					padding-left: 30px !important;
				}
			';

			break;

		case 'posts-list-widget-2':

			$out = '
				.timeline-widget .widget-title-icon:before {
					content: "\f073";
				}

				.timeline-widget ul {
					position: relative;
					padding-left: 15px;
				}

				.timeline-widget ul:before {
					content: "";
					position: absolute;
					left: 0;
					top: 0;
					width: 2px;
					height: 100%;
					background: #e6e6e6;
				}

				.timeline-widget li {
					border-bottom: 0;
					padding-bottom: 10px;
				}

				.timeline-widget li .date {
					font-size: 10px;
					display: block;
					position: relative;
					color: #767676;
					line-height: 12px;
					margin-bottom: 5px;
				}

				.timeline-widget li .date:before {
					content: "";
					width: 12px;
					height: 12px;
					background: #e6e6e6;
					border: 3px solid rgba(255, 255, 255, 0.8);
					position: absolute;
					left: -20px;
					display: inline-block;
					vertical-align: middle;
					border-radius: 50%;
					-webkit-transform: translateZ(0);
									transform: translateZ(0);
					-webkit-backface-visibility: hidden;
									backface-visibility: hidden;
					-webkit-font-smoothing: antialiased;
					-moz-osx-font-smoothing: grayscale;
					transition-duration: 0.3s;
				}

				.timeline-widget li h3 {
					font-size: 14px;
					line-height: 1.4;
				}

				.timeline-widget li a:hover .date:before {
					background: var(--brand-color);
					-webkit-transform: scale(1.2);
							-ms-transform: scale(1.2);
									transform: scale(1.2);
				}
			';
			break;

		case 'social':
				$out = '
				.social-icons-widget .widget-title-icon:before {
					content: "\f1e0";
				}

				.social-icons-widget ul {
					margin: 0 -3px;
				}

				.social-icons-widget .social-icons-item {
					float: left;
					margin: 3px;
					border-bottom: 0;
					padding: 0;
				}

				.social-icons-widget .social-icons-item .social-link {
					width: 40px;
					height: 40px;
					line-height: 40px;
					font-size: 18px;
				}

				.social-icons-widget .is-centered {
					text-align: center;
					overflow: hidden;
				}

				.social-icons-widget .is-centered .social-icons-item {
					float: none;
					display: inline-block;
				}

				@media (max-width: 479px) {
					.social-icons-widget .solid-social-icons {
						text-align: center;
					}
					.social-icons-widget .social-icons-item {
						float: none;
						display: inline-block;
					}
				}
			';
			break;

		case 'tie-tiktok-theme':
			$out = '
				.widget_tie-tiktok-theme .widget-title-icon:before {
					content: "\e90b";
				}

				.widget_tie-tiktok-theme .tiktok-feed-feed .tiktok-feed-list .tiktok-feed-item {
					padding: 5px !important;
				}

				.widget_tie-tiktok-theme .tiktok-feed-feed .tiktok-feed-list .tiktok-feed-item .tiktok-feed-video-mask-content > span,
				.widget_tie-tiktok-theme .tiktok-feed-feed .tiktok-feed-list .tiktok-feed-item .tiktok-feed-icon > span {
					font-weight: 400 !important;
					font-size: 12px !important;
				}

				.widget_tie-tiktok-theme .tiktok-feed-feed .tiktok-feed-actions {
					margin-bottom: 0;
					margin-right: -5px;
					margin-left: -5px;
				}

				.widget_tie-tiktok-theme .tiktok-feed-feed .tiktok-feed-actions .tiktok-feed-button {
					width: 100%;
					margin: 0;
				}

				.widget_tie-tiktok-theme .tiktok-feed-feed .tiktok-feed-actions .tiktok-feed-button:hover {
					box-shadow: 0px 9px 20px -5px #ff5374;
				}
			';
			break;

		case 'calendar':
			$out = '
				#wp-calendar {
					width: 100%;
				}

				#wp-calendar caption {
					font-weight: bold;
					margin-bottom: 15px;
					text-align: center;
				}

				#wp-calendar thead th {
					text-align: center;
					border: none;
				}

				#wp-calendar tbody {
					color: #aaa;
				}

				#wp-calendar tbody td {
					border: none;
					padding: 10px;
					text-align: center;
				}

				#wp-calendar tbody .pad {
					background: none;
					border: none;
				}

				#wp-calendar tfoot #next {
					text-align: right;
				}

				#wp-calendar #today {
					background-color: var(--brand-color);
				}

				#wp-calendar #today,
				#wp-calendar #today a {
					color: var(--bright-color);
				}
			';
			break;

		case 'author_widget':
			$out = '
				.widget_author .widget-title-icon:before {
					content: "\f007";
				}

				.widget_author .multiple-authors .about-author {
					border-width: 0;
					border-bottom-width: 1px;
					padding: 0 0 10px;
					margin-bottom: 20px;
				}

				.widget_author .multiple-authors .about-author:last-child {
					margin-bottom: 0;
					padding: 0;
					border-bottom-width: 0;
				}

				.widget_author .single-author .about-author {
					padding: 0;
					border: 0;
					margin: 0;
				}

				@media (min-width: 992px) {
					.widget_author div.author-avatar {
						float: none;
					}
					.widget_author div.author-avatar a {
						display: block;
						width: 90px;
						margin: 0 auto 10px;
					}
					.widget_author .author-info {
						padding: 0 !important;
					}
				}
			';
			break;

		case 'author-bio-widget':
			$out = '
				.aboutme-widget .widget-title-icon:before {
					content: "\f007";
				}

				.aboutme-widget .about-content-wrapper {
					overflow: hidden;
				}

				.fullwidth-area .aboutme-widget .about-content-wrapper {
					padding: 0 15%;
				}

				@media (max-width: 991px) {
					.aboutme-widget .about-content-wrapper {
						text-align: center;
					}
					.aboutme-widget .about-content-wrapper .aboutme-widget-content {
						max-width: 500px;
						margin: 0 auto;
					}
					.aboutme-widget .about-content-wrapper .social-icons li.social-icons-item {
						float: none;
						display: inline-block;
					}
				}

				.aboutme-widget .aboutme-widget-content {
					overflow: hidden;
					min-width: 140px;
				}

				.aboutme-widget .aboutme-widget-content h3 {
					margin-bottom: 10px;
				}

				.aboutme-widget .aboutme-widget-content span.tie-social-icon {
					margin-right: 5px;
					font-size: 16px;
					line-height: 25px;
				}

				.aboutme-widget .about-author-img {
					float: left;
					margin: 7px 20px 15px 0;
					width: auto;
					height: auto;
				}

				.aboutme-widget .about-author-img.lazy-img[data-src] {
					width: 100px;
					height: 100px;
				}

				@media (max-width: 991px) {
					.aboutme-widget .about-author-img {
						float: none;
						margin: 7px auto 15px;
					}
				}

				.aboutme-widget .social-icons {
					margin: 15px 0 0;
				}

				.aboutme-widget .social-icons:before {
					display: table;
					content: "";
					clear: both;
				}

				.aboutme-widget ul.about-info {
					margin-top: 10px;
				}

				@media (min-width: 992px) {
					.aboutme-widget .is-centered.about-content-wrapper {
						text-align: center;
					}
					.aboutme-widget .is-centered img.about-author-img {
						float: none;
						margin: 0 auto 10px;
					}
					.aboutme-widget .is-centered .social-icons li.social-icons-item {
						float: none;
						display: inline-block;
					}
				}

				.aboutme-widget .image-is-circle .about-author-img {
					border-radius: 100%;
				}

				.aboutme-widget .tie-padding {
					margin-bottom: 0;
				}
			';
			break;

		case 'tie-instagram-theme':
			$out = '
				.widget_tie-instagram-theme .widget-title-icon:before {
					content: "\f16d";
				}

				.widget_tie-instagram-theme .tie-insta-photos {
					margin: 0 -2px;
					clear: both;
				}

				.widget_tie-instagram-theme .tie-insta-post {
					padding: 0 2px 4px !important;
				}

				.widget_tie-instagram-theme .button {
					padding-top: 12px;
					padding-bottom: 12px;
					font-size: 14px;
					font-weight: bold;
					margin-top: 10px;
					background: #da2e7d;
					background: linear-gradient(29.61deg, #f38334 0%, #da2e7d 50.39%, #6b54c6 100%);
					transition: all 0.25s;
				}

				.widget_tie-instagram-theme .button:hover {
					margin-top: 8px;
					margin-bottom: 2px;
					box-shadow: 0px 9px 20px -5px #6b54c6;
					background: linear-gradient(150deg, #f38334 0%, #da2e7d 50.39%, #6b54c6 100%);
				}

				.widget_tie-instagram-theme .button .tie-icon-instagram {
					font-size: 12pt;
					vertical-align: text-bottom;
				}
			';
			break;

		case 'tie-widget-categories':
			$out = '	
				.tie-widget-categories li a:hover + span {
					box-shadow: inset 0 0 0 11px rgba(0, 0, 0, 0.3);
				}
				
				div.tie-widget-categories .children li {
					padding-left: 0;
					padding-right: 0;
				}
				
				.cat-counter a + span {
					display: inline-block;
					background-color: var(--brand-color);
					text-align: center;
					font-size: 85%;
					padding: 0 5px;
					min-width: 24px;
					height: 22px;
					line-height: 22px;
					color: var(--bright-color);
					border-radius: 2px;
					transition: box-shadow 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
				}			
			';
			break;

		case 'media_video':
			$out = '
				.widget_media_video .widget-title-icon:before {
					content: "\f04b";
				}
			
				.widget_media_video iframe,
				.widget_media_video video{
					max-width: 100%;
				}			
			';
			break;

		case 'media_image':
			$out = '
				.widget_media_image .widget-title-icon:before {
					content: "\f030";
				}
				
				.widget_media_image img{
					margin: 0 auto;
					display: block;
				}
			';
			break;

		case 'media_audio':
			$out = '
				.widget_media_audio .widget-title-icon:before {
					content: "\f025";
				}
			';
			break;

		case 'meta':
			$out = '
				.widget_meta .widget-title-icon:before {
					content: "\f0c1";
				}
			';
			break;

		case 'archives':
			$out = '
				.widget_archive .widget-title-icon:before {
					content: "\f187";
				}
			';
			break;

		case 'rss':
			$out = '
				.widget_rss .widget-title-icon:before {
					content: "\f09e";
				}
				
				.widget_rss img.rss-widget-icon {
					display: none;
				}
			';
			break;

		case 'tag_cloud':
			$out = '
				.fullwidth-area .widget_tag_cloud {
					text-align: center;
				}

				.fullwidth-area .widget_tag_cloud .widget-title {
					padding-bottom: 0;
					margin-bottom: 20px;
				}

				.fullwidth-area .widget_tag_cloud .widget-title .the-subtitle {
					font-weight: 700;
					font-size: 32px;
				}

				.fullwidth-area .widget_tag_cloud .widget-title:before, .fullwidth-area .widget_tag_cloud .widget-title:after {
					display: none;
				}

				.block-head-4 .fullwidth-area .widget_tag_cloud .widget-title {
					padding-top: 10px;
					padding-bottom: 10px;
				}

				.block-head-4 .fullwidth-area .widget_tag_cloud .widget-title:before {
					display: block;
				}

				.block-head-7 .fullwidth-area .widget_tag_cloud .widget-title {
					padding: 7px 10px;
				}

				.fullwidth-area .widget_tag_cloud .tagcloud a {
					background: rgba(0, 0, 0, 0.2);
					border-radius: 0;
					font-size: 20px !important;
					font-weight: 600;
					margin: 0 2px 6px 2px;
					padding: 14px 18px;
					border: none;
					text-transform: capitalize;
				}

				@media (max-width: 767px) {
					.fullwidth-area .widget_tag_cloud .tagcloud a {
						font-size: 14px !important;
						margin: 0 2px 6px 2px;
						padding: 10px 15px;
					}
				}

				.fullwidth-area .widget_tag_cloud .tagcloud a:hover {
					background-color: var(--brand-color);
					color: var(--bright-color);
				}
			';
			break;

		case 'tie-slider-widget':
			$out = '
				.tie-slider-widget .main-slider {
					z-index: 2;
				}

				.tie-slider-widget .slide img {
					display: none;
				}

				.normal-side .tie-slider-widget .container {
					width: 100%;
					max-width: none;
					margin: 0;
					padding: 0;
				}

				.normal-side .tie-slider-widget .tie-slick-slider:not(.slick-initialized) .slide:first-child {
					display: block !important;
				}

				.normal-side .tie-slider-widget .slick-list {
					width: 100%;
					margin: 0;
				}

				.normal-side .tie-slider-widget .slide {
					margin: 0;
					height: 220px;
				}

				@media only screen and (min-width: 480px) and (max-width: 768px) {
					.normal-side .tie-slider-widget .slide {
						height: 300px;
					}
				}

				@media only screen and (min-width: 768px) and (max-width: 992px) {
					.sidebar.normal-side .tie-slider-widget .slide {
						height: 400px;
					}
				}

				.normal-side .tie-slider-widget .thumb-overlay {
					padding: 20px;
				}

				.normal-side .tie-slider-widget .thumb-title {
					font-size: 18px;
				}

				.normal-side .tie-slider-widget .tie-slider-nav li {
					padding: 0;
				}

				.fullwidth-area .main-slider-inner > .container,
				.fullwidth-area > .container {
					padding: 0;
				}

				.fullwidth-area .tie-slick-dots {
					display: none !important;
				}
			';
			break;
	}

	return apply_filters( 'TieLabs/inline_styles/widgets', $out, $id );
}